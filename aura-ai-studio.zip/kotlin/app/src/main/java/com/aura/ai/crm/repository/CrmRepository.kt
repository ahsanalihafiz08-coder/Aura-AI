package com.aura.ai.crm.repository

import com.aura.ai.crm.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface defining operations for CRM, Lead Management, and Business Automation.
 */
interface CrmRepository {

    /**
     * Retrieves all leads in real-time from Cloud Firestore.
     */
    fun getLeads(): Flow<List<CrmLead>>

    /**
     * Saves or updates a lead document in Firestore.
     */
    suspend fun saveLead(lead: CrmLead)

    /**
     * Deletes a lead record from Firestore.
     */
    suspend fun deleteLead(leadId: String)

    /**
     * Retrieves real-time tasks associated with a given lead.
     */
    fun getTasksForLead(leadId: String): Flow<List<CrmTask>>

    /**
     * Saves or updates an interactive lead task.
     */
    suspend fun saveTask(task: CrmTask)

    /**
     * Retrieves all calendar meetings in real-time.
     */
    fun getMeetings(): Flow<List<CrmMeeting>>

    /**
     * Saves or updates a calendar meeting.
     */
    suspend fun saveMeeting(meeting: CrmMeeting)

    /**
     * Retrieves chronological activity log notes for a lead.
     */
    fun getNotesForLead(leadId: String): Flow<List<CrmNote>>

    /**
     * Appends an activity note or communications log.
     */
    suspend fun saveNote(note: CrmNote)

    /**
     * Uses integrated Gemini prompt engineering to score, qualify, and summarize a lead's profile.
     */
    suspend fun runAiQualification(lead: CrmLead, logs: List<CrmNote>): CrmLead

    /**
     * Generates custom, context-aware Outreach Emails using Gemini.
     */
    suspend fun generateSalesEmail(lead: CrmLead, goal: String): String

    /**
     * Generates conversational, high-converting WhatsApp follow-up templates using Gemini.
     */
    suspend fun generateWhatsAppMessage(lead: CrmLead, offerName: String): String
}
