package com.aura.ai.voice.model

import java.util.Date

/**
 * Supported assistant roles/modes for the voice agent.
 */
enum class AssistantMode(val label: String, val systemPrompt: String) {
    BUSINESS_SALES(
        "Business Sales Assistant",
        "You are Aura AI, a senior outbound business sales assistant. Your goal is to explain the high conversion metrics of Aura's CRM, overcome price objections, and direct the caller toward scheduling a premium software demo. Be energetic, persuasive, polite, and extremely action-oriented."
    ),
    APPOINTMENT_BOOKING(
        "Appointment Booking Coordinator",
        "You are Aura AI, a professional scheduling coordinator. Your goal is to guide the caller to select a convenient date and time for their consultation, gather corporate details, and confirm the appointment. Be helpful, organized, fast, and structured."
    ),
    CUSTOMER_SUPPORT(
        "Customer Support Specialist",
        "You are Aura AI, an empathetic and efficient client care specialist. Your goal is to resolve service issues, answer integration questions about WhatsApp or Firestore, and assure them of high system security. Be extremely calm, patient, supportive, and clear."
    )
}

/**
 * Voice settings representing speech synthesis preferences.
 */
data class VoiceSettings(
    val speed: Float = 1.0f, // Range 0.5f to 2.0f
    val pitch: Float = 1.0f, // Range 0.5f to 2.0f
    val language: String = "en-US", // Supported: en-US, es-ES, fr-FR, de-DE, ja-JP
    val mode: AssistantMode = AssistantMode.BUSINESS_SALES
)

/**
 * Represents a single verbal transcript message in the voice session.
 */
data class VoiceMessage(
    val id: String = "",
    val role: String = "agent", // "caller" (user) or "agent" (Aura AI)
    val content: String = "",
    val timestamp: Date = Date()
)

/**
 * Represents a voice calling session stored in Firestore.
 */
data class VoiceSession(
    val id: String = "",
    val userId: String = "",
    val title: String = "AI Voice Call",
    val status: String = "completed", // "connecting", "active", "completed", "failed"
    val durationSeconds: Int = 0,
    val speed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val language: String = "en-US",
    val assistantMode: String = "BUSINESS_SALES",
    val timestamp: Date = Date()
)

/**
 * Represents a call script generated for training or outbound campaigns.
 */
data class CallScript(
    val id: String = "",
    val title: String = "",
    val mode: AssistantMode = AssistantMode.BUSINESS_SALES,
    val language: String = "en-US",
    val generatedScript: String = ""
)
