package com.aura.ai.crm.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aura.ai.crm.model.*
import com.aura.ai.crm.usecase.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

class CrmViewModel(
    private val getLeadsUseCase: GetLeadsUseCase,
    private val saveLeadUseCase: SaveLeadUseCase,
    private val deleteLeadUseCase: DeleteLeadUseCase,
    private val getTasksForLeadUseCase: GetTasksForLeadUseCase,
    private val saveTaskUseCase: SaveTaskUseCase,
    private val getMeetingsUseCase: GetMeetingsUseCase,
    private val saveMeetingUseCase: SaveMeetingUseCase,
    private val getNotesForLeadUseCase: GetNotesForLeadUseCase,
    private val saveNoteUseCase: SaveNoteUseCase,
    private val runAiQualificationUseCase: RunAiQualificationUseCase,
    private val generateSalesEmailUseCase: GenerateSalesEmailUseCase,
    private val generateWhatsAppMessageUseCase: GenerateWhatsAppMessageUseCase,
    val userRole: UserRole = UserRole.ADMIN // Supports Role-Based Authorization Checks
) : ViewModel() {

    private val _leads = MutableStateFlow<List<CrmLead>>(emptyList())
    val leads: StateFlow<List<CrmLead>> = _leads.asStateFlow()

    private val _meetings = MutableStateFlow<List<CrmMeeting>>(emptyList())
    val meetings: StateFlow<List<CrmMeeting>> = _meetings.asStateFlow()

    private val _selectedLead = MutableStateFlow<CrmLead?>(null)
    val selectedLead: StateFlow<CrmLead?> = _selectedLead.asStateFlow()

    private val _selectedLeadTasks = MutableStateFlow<List<CrmTask>>(emptyList())
    val selectedLeadTasks: StateFlow<List<CrmTask>> = _selectedLeadTasks.asStateFlow()

    private val _selectedLeadNotes = MutableStateFlow<List<CrmNote>>(emptyList())
    val selectedLeadNotes: StateFlow<List<CrmNote>> = _selectedLeadNotes.asStateFlow()

    // Filter and UI Control States
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow<LeadStatus?>(null)
    val statusFilter: StateFlow<LeadStatus?> = _statusFilter.asStateFlow()

    private val _typeFilter = MutableStateFlow<LeadType?>(null)
    val typeFilter: StateFlow<LeadType?> = _typeFilter.asStateFlow()

    private val _isKanbanView = MutableStateFlow(false)
    val isKanbanView: StateFlow<Boolean> = _isKanbanView.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Generated Marketing/Outreach Templates state
    private val _generatedEmail = MutableStateFlow<String?>(null)
    val generatedEmail: StateFlow<String?> = _generatedEmail.asStateFlow()

    private val _generatedWhatsApp = MutableStateFlow<String?>(null)
    val generatedWhatsApp: StateFlow<String?> = _generatedWhatsApp.asStateFlow()

    init {
        loadLeads()
        loadMeetings()
    }

    private fun loadLeads() {
        viewModelScope.launch {
            getLeadsUseCase().catch { err ->
                _errorMessage.value = "Failed to sync leads: ${err.localizedMessage}"
            }.collect { list ->
                _leads.value = list
                // Refresh selected lead detail context if active
                _selectedLead.value?.let { current ->
                    _selectedLead.value = list.find { it.id == current.id }
                }
            }
        }
    }

    private fun loadMeetings() {
        viewModelScope.launch {
            getMeetingsUseCase().catch { err ->
                _errorMessage.value = "Failed to sync calendar meetings: ${err.localizedMessage}"
            }.collect { list ->
                _meetings.value = list
            }
        }
    }

    fun selectLead(lead: CrmLead?) {
        _selectedLead.value = lead
        _generatedEmail.value = null
        _generatedWhatsApp.value = null
        if (lead != null) {
            // Load Tasks and Notes of chosen Lead
            viewModelScope.launch {
                getTasksForLeadUseCase(lead.id).collect { tasks ->
                    _selectedLeadTasks.value = tasks
                }
            }
            viewModelScope.launch {
                getNotesForLeadUseCase(lead.id).collect { notes ->
                    _selectedLeadNotes.value = notes
                }
            }
        } else {
            _selectedLeadTasks.value = emptyList()
            _selectedLeadNotes.value = emptyList()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateStatusFilter(status: LeadStatus?) {
        _statusFilter.value = status
    }

    fun updateTypeFilter(type: LeadType?) {
        _typeFilter.value = type
    }

    fun toggleViewMode() {
        _isKanbanView.value = !_isKanbanView.value
    }

    /**
     * Creates a new Lead profile. Role authorized checks.
     */
    fun addNewLead(name: String, company: String, email: String, phone: String, value: Double, industry: String, notes: String) {
        if (userRole == UserRole.STAFF && value > 50000) {
            _errorMessage.value = "Access Denied: Standard Staff accounts cannot register Enterprise deals worth over $50k without manager approvals."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val lead = CrmLead(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    company = company,
                    email = email,
                    phone = phone,
                    status = LeadStatus.NEW,
                    type = LeadType.WARM,
                    value = value,
                    industry = industry,
                    notes = notes,
                    createdAt = Date(),
                    updatedAt = Date()
                )
                saveLeadUseCase(lead)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to register lead: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Mutate status in Kanban column drags or customer cards.
     */
    fun updateLeadStatus(leadId: String, newStatus: LeadStatus) {
        val lead = _leads.value.find { it.id == leadId } ?: return
        viewModelScope.launch {
            try {
                saveLeadUseCase(lead.copy(status = newStatus, updatedAt = Date()))
                // Auto qualify if moved to Qualified status
                if (newStatus == LeadStatus.QUALIFIED && lead.aiScore == 0) {
                    triggerAiQualification(leadId)
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to shift lead column: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Mutate Sales Pipeline temperature.
     */
    fun updateLeadType(leadId: String, newType: LeadType) {
        val lead = _leads.value.find { it.id == leadId } ?: return
        viewModelScope.launch {
            try {
                saveLeadUseCase(lead.copy(type = newType, updatedAt = Date()))
            } catch (e: Exception) {
                _errorMessage.value = "Failed to shift lead temperature: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Deletes a Lead. Only Administrators are permitted.
     */
    fun removeLead(leadId: String) {
        if (userRole != UserRole.ADMIN) {
            _errorMessage.value = "Access Denied: Administrative authority is required to remove leads."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                deleteLeadUseCase(leadId)
                if (_selectedLead.value?.id == leadId) {
                    selectLead(null)
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to purge lead record: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Saves a Task.
     */
    fun addNewTask(leadId: String, title: String, description: String, priority: String, dueDate: Date) {
        viewModelScope.launch {
            try {
                val task = CrmTask(
                    id = UUID.randomUUID().toString(),
                    leadId = leadId,
                    title = title,
                    description = description,
                    status = TaskStatus.PENDING,
                    priority = priority,
                    dueDate = dueDate,
                    createdAt = Date()
                )
                saveTaskUseCase(task)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to record task: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Toggle task progress state.
     */
    fun toggleTaskStatus(task: CrmTask) {
        val nextStatus = when (task.status) {
            TaskStatus.PENDING -> TaskStatus.IN_PROGRESS
            TaskStatus.IN_PROGRESS -> TaskStatus.COMPLETED
            TaskStatus.COMPLETED -> TaskStatus.PENDING
        }
        viewModelScope.launch {
            try {
                saveTaskUseCase(task.copy(status = nextStatus))
            } catch (e: Exception) {
                _errorMessage.value = "Failed to update task state: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Schedules a calendar meeting.
     */
    fun scheduleMeeting(leadId: String, title: String, description: String, dateTime: Date, location: String) {
        viewModelScope.launch {
            try {
                val meeting = CrmMeeting(
                    id = UUID.randomUUID().toString(),
                    leadId = leadId,
                    title = title,
                    description = description,
                    dateTime = dateTime,
                    locationLink = location,
                    status = "Scheduled",
                    createdAt = Date()
                )
                saveMeetingUseCase(meeting)
                
                // Also append a chronological timeline note automatically
                val timelineNote = CrmNote(
                    id = UUID.randomUUID().toString(),
                    leadId = leadId,
                    content = "Scheduled meeting: '$title' for ${dateTime.toString()}",
                    creatorId = userRole.name,
                    type = "Log",
                    timestamp = Date()
                )
                saveNoteUseCase(timelineNote)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to reserve meeting schedule: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Appends a customer card note.
     */
    fun addLeadNote(leadId: String, content: String, type: String = "Note") {
        viewModelScope.launch {
            try {
                val note = CrmNote(
                    id = UUID.randomUUID().toString(),
                    leadId = leadId,
                    content = content,
                    creatorId = userRole.name,
                    type = type,
                    timestamp = Date()
                )
                saveNoteUseCase(note)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to commit note: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Business Automation: AI automatically qualifies, scores, summarizes,
     * and recommends next steps for the lead based on its history.
     */
    fun triggerAiQualification(leadId: String) {
        val lead = _leads.value.find { it.id == leadId } ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val updatedLead = runAiQualificationUseCase(lead, _selectedLeadNotes.value)
                if (_selectedLead.value?.id == leadId) {
                    _selectedLead.value = updatedLead
                }
            } catch (e: Exception) {
                _errorMessage.value = "AI qualification engine error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Business Automation: AI generates sales outbound email copy.
     */
    fun generateEmailTemplate(leadId: String, goal: String) {
        val lead = _leads.value.find { it.id == leadId } ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                _generatedEmail.value = generateSalesEmailUseCase(lead, goal)
            } catch (e: Exception) {
                _errorMessage.value = "AI Email generation failed: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Business Automation: AI generates WhatsApp follow-up copy.
     */
    fun generateWhatsAppTemplate(leadId: String, offerName: String) {
        val lead = _leads.value.find { it.id == leadId } ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                _generatedWhatsApp.value = generateWhatsAppMessageUseCase(lead, offerName)
            } catch (e: Exception) {
                _errorMessage.value = "AI WhatsApp template generation failed: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Business Automation: CSV Data Portability - Import
     */
    fun importLeadsFromCsv(csvText: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val lines = csvText.lines()
                var importedCount = 0
                lines.forEachIndexed { idx, line ->
                    if (idx == 0 || line.trim().isEmpty()) return@forEachIndexed // Skip headers & spaces
                    val tokens = line.split(",")
                    if (tokens.size >= 4) {
                        val name = tokens[0].trim()
                        val company = tokens[1].trim()
                        val email = tokens[2].trim()
                        val phone = tokens[3].trim()
                        val value = tokens.getOrNull(4)?.toDoubleOrNull() ?: 5000.0
                        val industry = tokens.getOrNull(5)?.trim() ?: "Tech"
                        
                        val lead = CrmLead(
                            id = UUID.randomUUID().toString(),
                            name = name,
                            company = company,
                            email = email,
                            phone = phone,
                            status = LeadStatus.NEW,
                            type = LeadType.WARM,
                            value = value,
                            industry = industry,
                            notes = "Imported via CSV batch upload.",
                            createdAt = Date(),
                            updatedAt = Date()
                        )
                        saveLeadUseCase(lead)
                        importedCount++
                    }
                }
                addLeadNote("", "Successfully imported $importedCount CRM leads from external campaign CSV.")
            } catch (e: Exception) {
                _errorMessage.value = "CSV parsing/import error: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Business Automation: CSV Data Portability - Export
     */
    fun exportLeadsToCsv(): String {
        val builder = StringBuilder()
        builder.append("Name,Company,Email,Phone,Value,Industry,Status,PipelinePriority,AIScore\n")
        _leads.value.forEach { lead ->
            builder.append("${lead.name},${lead.company},${lead.email},${lead.phone},${lead.value},${lead.industry},${lead.status.name},${lead.type.name},${lead.aiScore}\n")
        }
        return builder.toString()
    }

    fun clearError() {
        _errorMessage.value = null
    }
}
