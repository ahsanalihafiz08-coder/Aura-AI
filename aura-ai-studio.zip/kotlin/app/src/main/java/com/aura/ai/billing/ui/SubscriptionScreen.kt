package com.aura.ai.billing.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.ai.billing.model.*
import com.aura.ai.billing.repository.PromoValidationResult
import com.aura.ai.billing.viewmodel.BillingViewModel

/**
 * High-fidelity, production-ready Jetpack Compose screen for Subscription, Billing & Revenue (Phase 8).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    viewModel: BillingViewModel,
    onBackClick: () -> Unit
) {
    val subState by viewModel.subscriptionState.collectAsState()
    val invoices by viewModel.invoiceHistory.collectAsState()
    val promoStatus by viewModel.promoStatus.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    var billingPeriod by remember { mutableStateOf(BillingPeriod.MONTHLY) }
    var promoInputText by remember { mutableStateOf("") }
    var showInvoiceDialog by remember { mutableStateOf<Invoice?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "Monetization & Plans",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        fontSize = 18sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFAFAFC)
                )
            )
        },
        containerColor = Color(0xFFFAFAFC)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // 1. ACTIVE SUBSCRIPTION STATUS BANNER
            item {
                ActiveSubscriptionBanner(
                    state = subState,
                    onCancelClick = { viewModel.cancelActiveSubscription() },
                    onRestoreClick = { viewModel.restoreUserPurchases() }
                )
            }

            // 2. BILLING CYCLE PERIOD SELECTOR
            item {
                BillingPeriodToggle(
                    selectedPeriod = billingPeriod,
                    onPeriodChange = { billingPeriod = it }
                )
            }

            // 3. PRICING SAAS TIERS LIST
            items(viewModel.subscriptionPlans) { plan ->
                PricingTierCard(
                    plan = plan,
                    period = billingPeriod,
                    isActive = subState.tier == plan.tier,
                    discountPercent = subState.discountPercent,
                    onSelect = {
                        viewModel.startPurchaseFlow(
                            activity = Any(), // Android context placeholder
                            planId = plan.id,
                            period = billingPeriod,
                            coupon = subState.activeCouponCode ?: promoInputText.ifBlank { null }
                        )
                    }
                )
            }

            // 4. COUPON / PROMO CODES SYSTEM
            item {
                PromoCodeSection(
                    inputText = promoInputText,
                    onTextChange = { promoInputText = it },
                    status = promoStatus,
                    isLoading = isLoading,
                    onApply = { viewModel.applyCoupon(promoInputText) }
                )
            }

            // 5. REVENUE ANALYTICS & SAAS METRICS DASHBOARD
            item {
                RevenueAnalyticsDashboard(invoices = invoices)
            }

            // 6. INVOICING & TRANSACTION HISTORY
            item {
                PaymentHistorySection(
                    invoices = invoices,
                    onDownloadClick = { invoice -> showInvoiceDialog = invoice }
                )
            }

            // Spacer
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // SIMULATED INVOICE PDF GENERATOR DIALOG
    showInvoiceDialog?.let { invoice ->
        SimulatedInvoiceDialog(
            invoice = invoice,
            onDismiss = { showInvoiceDialog = null }
        )
    }
}

@Composable
fun ActiveSubscriptionBanner(
    state: UserSubscriptionState,
    onCancelClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (state.isActive) Color(0xFFEEF2FF) else Color(0xFFF1F5F9)
        ),
        border = BorderStroke(1.dp, if (state.isActive) Color(0xFFC7D2FE) else Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (state.isActive) Icons.Default.CheckCircle else Icons.Default.Info,
                        contentDescription = "Subscription Level",
                        tint = if (state.isActive) Color(0xFF4F46E5) else Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isActive) "Active plan: ${state.tier}" else "Free Plan",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14sp,
                        color = Color(0xFF1E293B)
                    )
                }

                if (state.isActive) {
                    val label = if (state.isCancelled) "Canceled (Pending End)" else "Renewal Active"
                    val color = if (state.isCancelled) Color(0xFFDC2626) else Color(0xFF16A34A)
                    Box(
                        modifier = Modifier
                            .background(color.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = label, color = color, fontSize = 10sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (state.isActive) {
                Text(
                    text = "Your premium access remains active until ${state.expiresAt ?: "next cycle"}. Auto-billing is executed via Google Play Account.",
                    fontSize = 11sp,
                    color = Color(0xFF475569)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (!state.isCancelled) {
                        Text(
                            text = "Cancel Auto-Renew",
                            color = Color(0xFFDC2626),
                            fontSize = 11sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { onCancelClick() }
                                .padding(vertical = 4.dp)
                        )
                    }
                    Text(
                        text = "Restore Transactions",
                        color = Color(0xFF4F46E5),
                        fontSize = 11sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onRestoreClick() }
                            .padding(vertical = 4.dp)
                    )
                }
            } else {
                Text(
                    text = "Unlock professional tools like official WhatsApp template managers, unlimited CRM pipelines, and low-latency interactive outbound Voice agents.",
                    fontSize = 11sp,
                    color = Color(0xFF64748B)
                )
                Button(
                    onClick = onRestoreClick,
                    modifier = Modifier.align(Alignment.End),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(text = "Restore Purchases", fontSize = 10sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BillingPeriodToggle(
    selectedPeriod: BillingPeriod,
    onPeriodChange: (BillingPeriod) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFE2E8F0))
            .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        val options = listOf(BillingPeriod.MONTHLY to "Monthly Billing", BillingPeriod.YEARLY to "Yearly (-20% ARR discount)")
        options.forEach { (period, title) ->
            val isSelected = selectedPeriod == period
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) Color.White else Color.Transparent)
                    .clickable { onPeriodChange(period) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = title,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 11sp,
                    color = if (isSelected) Color(0xFF4F46E5) else Color(0xFF475569)
                )
            }
        }
    }
}

@Composable
fun PricingTierCard(
    plan: SubscriptionPlan,
    period: BillingPeriod,
    isActive: Boolean,
    discountPercent: Int,
    onSelect: () -> Unit
) {
    val rawPrice = if (period == BillingPeriod.MONTHLY) plan.priceMonthly else plan.priceYearly / 12
    val priceText = String.format("$%.2f", rawPrice * (1.0 - (discountPercent / 100.0)))
    val labelPeriod = if (period == BillingPeriod.MONTHLY) "/mo" else "/mo (billed annually)"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) Color(0xFFEEF2FF) else Color.White
        ),
        border = BorderStroke(2.dp, if (isActive) Color(0xFF4F46E5) else Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = plan.name,
                        fontWeight = FontWeight.Black,
                        fontSize = 16sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "Includes ${plan.trialDays}-day free trial.",
                        fontSize = 10sp,
                        color = Color(0xFF64748B)
                    )
                }

                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = priceText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20sp,
                        color = Color(0xFF4F46E5)
                    )
                    Text(
                        text = labelPeriod,
                        fontSize = 10sp,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }

            Divider(color = Color(0xFFF1F5F9))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                plan.features.forEach { feature ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Feature check",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = feature,
                            fontSize = 11sp,
                            color = Color(0xFF475569)
                        )
                    }
                }
            }

            Button(
                onClick = onSelect,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) Color(0xFF16A34A) else Color(0xFF4F46E5)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = if (isActive) "Currently Active Plan" else "Select Plan & Start Trial",
                    fontSize = 11sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun PromoCodeSection(
    inputText: String,
    onTextChange: (String) -> Unit,
    status: PromoValidationResult?,
    isLoading: Boolean,
    onApply: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Apply Promo Code",
                fontWeight = FontWeight.Bold,
                fontSize = 11sp,
                color = Color(0xFF475569)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = onTextChange,
                    placeholder = { Text(text = "AURAEARLY50", fontSize = 11sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12sp, fontFamily = FontFamily.Monospace)
                )

                Button(
                    onClick = onApply,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Text(text = "Apply", fontSize = 11sp)
                    }
                }
            }

            status?.let { res ->
                val (color, text) = when (res) {
                    is PromoValidationResult.Valid -> Color(0xFF16A34A) to "Coupon Accepted! ${res.discountPercent}% off applied to checkout."
                    is PromoValidationResult.Invalid -> Color(0xFFDC2626) to "Coupon Rejected: ${res.reason}"
                }
                Text(text = text, color = color, fontSize = 10sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun RevenueAnalyticsDashboard(invoices: List<Invoice>) {
    val totalPaid = invoices.filter { it.status == "Paid" }.sumOf { it.amount }
    val mrrValue = invoices.filter { it.status == "Paid" && it.billingPeriod == "Monthly" }.sumOf { it.amount }
    val arrValue = mrrValue * 12

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)) // Dark theme for analytics look
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "SaaS Revenue Analytics",
                fontWeight = FontWeight.Black,
                color = Color.White,
                fontSize = 12sp,
                fontFamily = FontFamily.SansSerif
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "YOUR CONTRIBUTION", color = Color(0xFF94A3B8), fontSize = 9sp)
                    Text(text = String.format("$%.2f", totalPaid), color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 16sp)
                }
                Column {
                    Text(text = "SIMULATED MRR", color = Color(0xFF94A3B8), fontSize = 9sp)
                    Text(text = String.format("$%.2f", mrrValue), color = Color(0xFF34D399), fontWeight = FontWeight.Bold, fontSize = 16sp)
                }
                Column {
                    Text(text = "ESTIMATED ARR", color = Color(0xFF94A3B8), fontSize = 9sp)
                    Text(text = String.format("$%.2f", arrValue), color = Color(0xFFA78BFA), fontWeight = FontWeight.Bold, fontSize = 16sp)
                }
            }

            // SIMULATED MINI CHART REPRESENTATION
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    val heights = listOf(0.2f, 0.4f, 0.35f, 0.6f, 0.8f, 0.95f)
                    heights.forEachIndexed { idx, pct ->
                        Box(
                            modifier = Modifier
                                .width(12.dp)
                                .fillMaxHeight(pct)
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color(0xFF38BDF8), Color(0xFF3B82F6))
                                    )
                                )
                        )
                    }
                }
            }
            Text(
                text = "Simulated billing cycles track live subscription upgrades & discount codes applied.",
                fontSize = 9sp,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun PaymentHistorySection(
    invoices: List<Invoice>,
    onDownloadClick: (Invoice) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Payment Logs & Receipts",
            fontWeight = FontWeight.Black,
            fontSize = 12sp,
            color = Color(0xFF1E293B)
        )

        if (invoices.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No prior transaction logs. Complete a purchase sandbox flow to compile invoices.",
                    fontSize = 11sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                invoices.forEach { invoice ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = invoice.invoiceNumber, fontWeight = FontWeight.Bold, fontSize = 11sp, color = Color(0xFF1E293B))
                                Text(text = "${invoice.planName} (${invoice.billingPeriod})", fontSize = 9sp, color = Color(0xFF64748B))
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = String.format("$%.2f", invoice.amount), fontWeight = FontWeight.Bold, fontSize = 12sp, color = Color(0xFF1E293B))
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Download Receipt",
                                    tint = Color(0xFF4F46E5),
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable { onDownloadClick(invoice) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatedInvoiceDialog(
    invoice: Invoice,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))) {
                Text(text = "Close Receipt")
            }
        },
        title = {
            Text(text = "Invoice Dispatch", fontWeight = FontWeight.Black, fontSize = 16sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "Aura AI Studio Billing Service", fontWeight = FontWeight.Bold, fontSize = 12sp)
                Text(text = "Document ID: ${invoice.id}", fontSize = 10sp, fontFamily = FontFamily.Monospace)
                Text(text = "Transaction Number: ${invoice.invoiceNumber}", fontSize = 10sp, fontFamily = FontFamily.Monospace)
                Divider()
                Text(text = "Plan: ${invoice.planName}", fontSize = 11sp)
                Text(text = "Period: ${invoice.billingPeriod}", fontSize = 11sp)
                Text(text = "Charged Date: ${invoice.date}", fontSize = 11sp)
                Text(text = "Grand Total Charged: $${String.format("%.2f", invoice.amount)} USD", fontSize = 12sp, fontWeight = FontWeight.Bold, color = Color(0xFF4F46E5))
                Divider()
                Text(text = "Simulated receipt exported to digital PDF. Direct link is available at: \n${invoice.pdfUrl}", fontSize = 9sp, color = Color(0xFF64748B))
            }
        }
    )
}
