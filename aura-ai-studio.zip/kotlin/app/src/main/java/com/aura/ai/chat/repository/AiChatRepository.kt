package com.aura.ai.chat.repository

import com.aura.ai.chat.model.ChatMessage
import com.aura.ai.chat.model.ChatSession
import kotlinx.coroutines.flow.Flow

/**
 * Interface defining operations for the Aura AI Chat Assistant.
 * Follows Clean Architecture separation of concerns.
 */
interface AiChatRepository {
    
    /**
     * Observes all active conversation sessions for the authenticated user from Firestore.
     */
    fun getChatSessions(userId: String): Flow<List<ChatSession>>

    /**
     * Observes the message history for a specific conversation session.
     */
    fun getMessageHistory(sessionId: String): Flow<List<ChatMessage>>

    /**
     * Sends a message to the secure Aura backend and streams the response chunks.
     * @param sessionId Optional existing session ID; if null, a new session is initialized.
     * @param message User's input message text.
     * @param imageBytes Optional attached image bytes (for multimodal input).
     * @param imageMime Optional attached image MIME type.
     * @return A Flow emitting real-time text chunks, token counts, or errors.
     */
    fun sendMessageStream(
        userId: String,
        sessionId: String?,
        message: String,
        imageBytes: ByteArray? = null,
        imageMime: String? = null
    ): Flow<StreamResponse>

    /**
     * Permanently deletes an active conversation session and its history from Firestore.
     */
    suspend fun deleteChatSession(sessionId: String)

    /**
     * Renames a conversation session with a custom user title in Firestore.
     */
    suspend fun renameChatSession(sessionId: String, newTitle: String)
}

/**
 * Encapsulates real-time response types emitted by the streaming flow.
 */
sealed class StreamResponse {
    data class ContentChunk(val text: String) : StreamResponse()
    data class TokenMetrics(val prompt: Int, val candidates: Int) : StreamResponse()
    data class SessionInitialized(val sessionId: String, val autoTitle: String) : StreamResponse()
    data class Error(val throwable: Throwable) : StreamResponse()
}
