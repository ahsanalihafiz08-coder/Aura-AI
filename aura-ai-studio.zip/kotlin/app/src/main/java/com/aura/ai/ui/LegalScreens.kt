package com.aura.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Privacy Policy Screen - Play Store Compliance.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(
    onBackClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy Policy", fontWeight = FontWeight.Bold, fontSize = 18sp) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFAFAFC))
            )
        },
        containerColor = Color(0xFFFAFAFC)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Last Updated: July 10, 2026",
                fontWeight = FontWeight.SemiBold,
                fontSize = 12sp,
                color = Color.Gray
            )

            Text(
                text = "1. Information We Collect",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "Aura AI Studio (\"the App\") utilizes secure Cloud Firestore and Gemini AI services. We collect account identifier metadata (emails, display names) during authentication. Lead pipelines and outreach metrics logged by users are stored securely in cloud-hosted Firestore database configurations linked to user credentials.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Text(
                text = "2. How We Use Information",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "Collected data is used solely to provide core service automation: drafting outbound campaign templates, managing CRM pipelines, tracking sales conversion analytics, and powering neural-synthesized outbound calling agents. No third-party data tracking or profile broker sharing is ever performed.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Text(
                text = "3. AI Services & Third Party API Processing",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "Message streams, transcribed calls, and CRM qualification triggers are proxied securely to Gemini AI language models. Payloads do not include structural business credentials and are treated in strict compliance with developer privacy regulations. Local cache contents remain encrypted on the physical device.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Text(
                text = "4. User Security and Rights",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "Users have complete control over data removal. You can delete active chat records, pipeline lead summaries, or initiate immediate user profile purging directly inside the settings module.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Terms and Conditions Screen - Play Store Compliance.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TermsAndConditionsScreen(
    onBackClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Terms & Conditions", fontWeight = FontWeight.Bold, fontSize = 18sp) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFAFAFC))
            )
        },
        containerColor = Color(0xFFFAFAFC)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Last Updated: July 10, 2026",
                fontWeight = FontWeight.SemiBold,
                fontSize = 12sp,
                color = Color.Gray
            )

            Text(
                text = "1. Agreement to Terms",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "By accessing Aura AI Studio, you agree to adhere to these terms. Users must be authorized business administrators and represent authentic business outreach campaigns. Abuse or malicious scraping through our automation APIs will result in immediate termination.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Text(
                text = "2. Subscriptions & Billing Cycles",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "Paid tiers (Pro, Business, Enterprise) are managed securely via Google Play In-App Billing v7 subscriptions. Fees are charged in recurring monthly or annual intervals. Refunds and subscription terminations are governed by official Google Play Store policies.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Text(
                text = "3. Fair Use of Voice Calling and SMS",
                fontWeight = FontWeight.Bold,
                fontSize = 16sp,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "Outbound dialing and VoIP integrations are strictly prohibited for spam campaigns. Standard telecommunication compliance (including TCPA and regional consent boundaries) must be verified and enforced by the operating business entity.",
                fontSize = 14sp,
                color = Color(0xFF475569)
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
