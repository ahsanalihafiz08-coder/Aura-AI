package com.aura.ai.crm.usecase

import com.aura.ai.crm.model.*
import com.aura.ai.crm.repository.CrmRepository
import kotlinx.coroutines.flow.Flow

class GetLeadsUseCase(private val repository: CrmRepository) {
    operator fun invoke(): Flow<List<CrmLead>> = repository.getLeads()
}

class SaveLeadUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(lead: CrmLead) = repository.saveLead(lead)
}

class DeleteLeadUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(leadId: String) = repository.deleteLead(leadId)
}

class GetTasksForLeadUseCase(private val repository: CrmRepository) {
    operator fun invoke(leadId: String): Flow<List<CrmTask>> = repository.getTasksForLead(leadId)
}

class SaveTaskUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(task: CrmTask) = repository.saveTask(task)
}

class GetMeetingsUseCase(private val repository: CrmRepository) {
    operator fun invoke(): Flow<List<CrmMeeting>> = repository.getMeetings()
}

class SaveMeetingUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(meeting: CrmMeeting) = repository.saveMeeting(meeting)
}

class GetNotesForLeadUseCase(private val repository: CrmRepository) {
    operator fun invoke(leadId: String): Flow<List<CrmNote>> = repository.getNotesForLead(leadId)
}

class SaveNoteUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(note: CrmNote) = repository.saveNote(note)
}

class RunAiQualificationUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(lead: CrmLead, logs: List<CrmNote>): CrmLead {
        return repository.runAiQualification(lead, logs)
    }
}

class GenerateSalesEmailUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(lead: CrmLead, goal: String): String {
        return repository.generateSalesEmail(lead, goal)
    }
}

class GenerateWhatsAppMessageUseCase(private val repository: CrmRepository) {
    suspend operator fun invoke(lead: CrmLead, offerName: String): String {
        return repository.generateWhatsAppMessage(lead, offerName)
    }
}
