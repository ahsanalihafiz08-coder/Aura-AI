package com.aura.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aura.ai.chat.repository.AiChatRepositoryImpl
import com.aura.ai.chat.viewmodel.AiChatViewModel
import com.aura.ai.chat.ui.AiChatScreen
import com.aura.ai.crm.repository.CrmRepositoryImpl
import com.aura.ai.crm.usecase.*
import com.aura.ai.crm.viewmodel.CrmViewModel
import com.aura.ai.crm.ui.CrmScreen
import com.aura.ai.billing.repository.BillingRepositoryImpl
import com.aura.ai.billing.viewmodel.BillingViewModel
import com.aura.ai.billing.ui.SubscriptionScreen
import com.aura.ai.voice.repository.VoiceAgentRepositoryImpl
import com.aura.ai.voice.usecase.*
import com.aura.ai.voice.viewmodel.VoiceAgentViewModel
import com.aura.ai.voice.ui.VoiceAgentScreen
import com.aura.ai.ui.DashboardScreen
import com.aura.ai.ui.PrivacyPolicyScreen
import com.aura.ai.ui.TermsAndConditionsScreen
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.OkHttpClient
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {

    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val httpClient by lazy { OkHttpClient() }
    
    // Constant credentials for active session sandbox
    private val testUserId = "user_aura_sandbox_2026"
    private val testSubscriptionTier = "Business"

    // Permission request contract
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Toast.makeText(this, "Microphone access enabled for voice outreach", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Voice transcription capabilities might be limited", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Ensure record audio permission is checked/requested for Voice Agent Screen
        checkVoicePermissions()

        setContent {
            AuraTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }

    private fun checkVoicePermissions() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    @Composable
    private fun AppNavigation() {
        val navController = rememberNavController()

        // 1. Instantiation of Repositories & Services
        val aiChatRepository = remember { AiChatRepositoryImpl(firestore, httpClient) }
        val crmRepository = remember { CrmRepositoryImpl(firestore) }
        val billingRepository = remember { BillingRepositoryImpl(firestore, httpClient) }
        val voiceRepository = remember { VoiceAgentRepositoryImpl(firestore, httpClient) }

        // 2. Instantiation of Use Cases for CRM module
        val getLeadsUseCase = remember { GetLeadsUseCase(crmRepository) }
        val saveLeadUseCase = remember { SaveLeadUseCase(crmRepository) }
        val deleteLeadUseCase = remember { DeleteLeadUseCase(crmRepository) }
        val getTasksForLeadUseCase = remember { GetTasksForLeadUseCase(crmRepository) }
        val saveTaskUseCase = remember { SaveTaskUseCase(crmRepository) }
        val getMeetingsUseCase = remember { GetMeetingsUseCase(crmRepository) }
        val saveMeetingUseCase = remember { SaveMeetingUseCase(crmRepository) }
        val getNotesForLeadUseCase = remember { GetNotesForLeadUseCase(crmRepository) }
        val saveNoteUseCase = remember { SaveNoteUseCase(crmRepository) }
        val runAiQualificationUseCase = remember { RunAiQualificationUseCase(crmRepository) }
        val generateSalesEmailUseCase = remember { GenerateSalesEmailUseCase(crmRepository) }
        val generateWhatsAppMessageUseCase = remember { GenerateWhatsAppMessageUseCase(crmRepository) }

        // 3. Instantiation of Use Cases for Voice Agent module
        val startVoiceSessionUseCase = remember { StartVoiceSessionUseCase(voiceRepository) }
        val saveVoiceSessionUseCase = remember { SaveVoiceSessionUseCase(voiceRepository) }
        val processVoiceExchangeUseCase = remember { ProcessVoiceExchangeUseCase(voiceRepository) }
        val generateCallScriptUseCase = remember { GenerateCallScriptUseCase(voiceRepository) }

        // 4. Instantiation of ViewModels with Clean Architectures
        val chatViewModel = remember { 
            AiChatViewModel(
                repository = aiChatRepository, 
                userId = testUserId, 
                subscriptionTier = testSubscriptionTier
            ) 
        }
        val crmViewModel = remember {
            CrmViewModel(
                getLeadsUseCase = getLeadsUseCase,
                saveLeadUseCase = saveLeadUseCase,
                deleteLeadUseCase = deleteLeadUseCase,
                getTasksForLeadUseCase = getTasksForLeadUseCase,
                saveTaskUseCase = saveTaskUseCase,
                getMeetingsUseCase = getMeetingsUseCase,
                saveMeetingUseCase = saveMeetingUseCase,
                getNotesForLeadUseCase = getNotesForLeadUseCase,
                saveNoteUseCase = saveNoteUseCase,
                runAiQualificationUseCase = runAiQualificationUseCase,
                generateSalesEmailUseCase = generateSalesEmailUseCase,
                generateWhatsAppMessageUseCase = generateWhatsAppMessageUseCase
            )
        }
        val billingViewModel = remember {
            BillingViewModel(
                billingRepository = billingRepository,
                userId = testUserId
            )
        }
        val voiceViewModel = remember {
            VoiceAgentViewModel(
                startVoiceSessionUseCase = startVoiceSessionUseCase,
                saveVoiceSessionUseCase = saveVoiceSessionUseCase,
                processVoiceExchangeUseCase = processVoiceExchangeUseCase,
                generateCallScriptUseCase = generateCallScriptUseCase,
                userId = testUserId
            )
        }

        NavHost(
            navController = navController,
            startDestination = "dashboard"
        ) {
            composable("dashboard") {
                DashboardScreen(
                    onNavigateToChat = { navController.navigate("chat") },
                    onNavigateToCrm = { navController.navigate("crm") },
                    onNavigateToBilling = { navController.navigate("billing") },
                    onNavigateToVoiceAgent = { navController.navigate("voice") },
                    onNavigateToPrivacy = { navController.navigate("privacy") },
                    onNavigateToTerms = { navController.navigate("terms") }
                )
            }
            composable("chat") {
                AiChatScreen(
                    viewModel = chatViewModel,
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("crm") {
                CrmScreen(
                    viewModel = crmViewModel,
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("billing") {
                SubscriptionScreen(
                    viewModel = billingViewModel,
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("voice") {
                VoiceAgentScreen(
                    viewModel = voiceViewModel,
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("privacy") {
                PrivacyPolicyScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("terms") {
                TermsAndConditionsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF6366F1),
            secondary = Color(0xFF4F46E5),
            background = Color(0xFFF8FAFC)
        ),
        content = content
    )
}

// Light colors helper
fun lightColorScheme(
    primary: Color,
    secondary: Color,
    background: Color
) = androidx.compose.material3.lightColorScheme(
    primary = primary,
    secondary = secondary,
    background = background,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)
