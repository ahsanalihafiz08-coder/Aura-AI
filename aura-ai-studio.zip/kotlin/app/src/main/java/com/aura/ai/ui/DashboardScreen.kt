package com.aura.ai.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToChat: () -> Unit,
    onNavigateToCrm: () -> Unit,
    onNavigateToBilling: () -> Unit,
    onNavigateToVoiceAgent: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToTerms: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Aura AI Logo",
                            tint = Color(0xFF6366F1),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Aura AI Studio",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20sp,
                            color = Color(0xFF0F172A)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF8FAFC)),
                actions = {
                    IconButton(onClick = onNavigateToBilling) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Subscription",
                            tint = Color(0xFF475569)
                        )
                    }
                }
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero card banner with elegant background gradient
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF6366F1), Color(0xFF4F46E5))
                        )
                    )
                    .padding(20.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Column {
                    Text(
                        text = "Welcome to Aura AI",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Your next-gen CRM, voice agent and neural messaging workspace is online.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13sp
                    )
                }
            }

            // Quick Stats Row
            Text(
                text = "Performance Metrics",
                fontWeight = FontWeight.Bold,
                fontSize = 15sp,
                color = Color(0xFF334155),
                modifier = Modifier.padding(top = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardStatCard(
                    title = "Total Revenue",
                    value = "$42,850",
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFE0E7FF)
                )
                DashboardStatCard(
                    title = "Active Sessions",
                    value = "14 Calls",
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFF5E6FF)
                )
                DashboardStatCard(
                    title = "Conversion",
                    value = "+28.4%",
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFD1FAE5)
                )
            }

            // Core features section
            Text(
                text = "Core Automation Suite",
                fontWeight = FontWeight.Bold,
                fontSize = 15sp,
                color = Color(0xFF334155),
                modifier = Modifier.padding(top = 8.dp)
            )

            DashboardModuleCard(
                title = "AI Neural Chat Suite",
                subtitle = "Discuss deals and draft high-converting proposals with live contextual data.",
                icon = Icons.Default.Send,
                badgeText = "Gemini Pro",
                badgeColor = Color(0xFFECFDF5),
                badgeTextColor = Color(0xFF047857),
                onClick = onNavigateToChat
            )

            DashboardModuleCard(
                title = "Intelligent CRM Pipelines",
                subtitle = "Convert cold leads into loyal accounts with automatic categorization.",
                icon = Icons.Default.List,
                badgeText = "Automated",
                badgeColor = Color(0xFFEFF6FF),
                badgeTextColor = Color(0xFF1D4ED8),
                onClick = onNavigateToCrm
            )

            DashboardModuleCard(
                title = "Neural Outbound Voice Agent",
                subtitle = "Synthesize natural outbound phone calling campaigns with real-time feedback.",
                icon = Icons.Default.Phone,
                badgeText = "Real-time",
                badgeColor = Color(0xFFFFF7ED),
                badgeTextColor = Color(0xFFC2410C),
                onClick = onNavigateToVoiceAgent
            )

            DashboardModuleCard(
                title = "Subscriptions & Invoices",
                subtitle = "Upgrade to unlock enterprise APIs, custom voices, and high quota boundaries.",
                icon = Icons.Default.ShoppingCart,
                badgeText = "Play Billing",
                badgeColor = Color(0xFFFAF5FF),
                badgeTextColor = Color(0xFF7E22CE),
                onClick = onNavigateToBilling
            )

            // Legal & Compliance Footer (Play Store Requirement)
            Spacer(modifier = Modifier.height(20.dp))
            Divider(color = Color(0xFFE2E8F0))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Text(
                    text = "Privacy Policy",
                    fontSize = 13sp,
                    color = Color(0xFF6366F1),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clickable { onNavigateToPrivacy() }
                        .padding(8.dp)
                )
                Text(
                    text = "Terms & Conditions",
                    fontSize = 13sp,
                    color = Color(0xFF6366F1),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clickable { onNavigateToTerms() }
                        .padding(8.dp)
                )
            }
            
            Text(
                text = "Version 1.0.0 (Build 1)\n© 2026 Aura AI Studio. All rights reserved.",
                fontSize = 11sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            )
        }
    }
}

@Composable
fun DashboardStatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    color: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color)
            .padding(14.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF475569)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 16sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
        }
    }
}

@Composable
fun DashboardModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badgeText: String,
    badgeColor: Color,
    badgeTextColor: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF1F5F9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color(0xFF4F46E5),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15sp,
                        color = Color(0xFF0F172A)
                    )
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(badgeColor)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 10sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeTextColor
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = subtitle,
                fontSize = 12sp,
                color = Color(0xFF64748B),
                lineHeight = 16sp
            )
        }
    }
}
