package com.aura.ai.chat.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aura.ai.chat.model.ChatMessage
import com.aura.ai.chat.model.ChatSession
import com.aura.ai.chat.repository.AiChatRepository
import com.aura.ai.chat.repository.StreamResponse
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Date

class AiChatViewModel(
    private val repository: AiChatRepository,
    private val userId: String,
    private val subscriptionTier: String // "Starter" or "Business"
) : ViewModel() {

    // Immutable state flows backing our Jetpack Compose layout
    private val _sessions = MutableStateFlow<List<ChatSession>>(emptyList())
    val sessions: StateFlow<List<ChatSession>> = _sessions.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _activeSessionId = MutableStateFlow<String?>(null)
    val activeSessionId: StateFlow<String?> = _activeSessionId.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _voiceRecordingState = MutableStateFlow("idle") // "idle", "recording", "transcribing"
    val voiceRecordingState: StateFlow<String> = _voiceRecordingState.asStateFlow()

    private val _dailyQueryCount = MutableStateFlow(0)
    val dailyQueryCount: StateFlow<Int> = _dailyQueryCount.asStateFlow()

    private val _promptTokens = MutableStateFlow(0)
    private val _candidateTokens = MutableStateFlow(0)
    val tokenStats = combine(_promptTokens, _candidateTokens) { p, c ->
        Pair(p, c)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Pair(0, 0))

    // Attached Image parameters
    var attachedImageBytes: ByteArray? = null
    var attachedImageMime: String? = null

    init {
        loadChatSessions()
        observeActiveSessionMessages()
    }

    private fun loadChatSessions() {
        viewModelScope.launch {
            repository.getChatSessions(userId)
                .catch { _errorMessage.value = "Failed to synchronize chat rooms: ${it.localizedMessage}" }
                .collect { list ->
                    _sessions.value = list
                }
        }
    }

    private fun observeActiveSessionMessages() {
        viewModelScope.launch {
            _activeSessionId.collectLatest { sessionId ->
                if (sessionId != null) {
                    repository.getMessageHistory(sessionId)
                        .catch { _errorMessage.value = "History sync error: ${it.localizedMessage}" }
                        .collect { history ->
                            _messages.value = history
                        }
                } else {
                    _messages.value = emptyList()
                }
            }
        }
    }

    /**
     * Dispatch user input to Gemini with streaming output and Firestore write-through.
     */
    fun sendMessage(content: String) {
        if (content.trim().isEmpty() && attachedImageBytes == null) return

        // Daily Limit Check for Free/Starter Users (5 Queries per 24 hours)
        if (subscriptionTier == "Starter" && _dailyQueryCount.value >= 5) {
            _errorMessage.value = "Daily message quota of 5 queries exceeded on Starter tier. Upgrade to Business!"
            return
        }

        val promptText = content.trim()
        val currentSessionId = _activeSessionId.value
        val imageBytes = attachedImageBytes
        val imageMime = attachedImageMime

        // Clear image attachment state immediately on draft send
        attachedImageBytes = null
        attachedImageMime = null

        viewModelScope.launch {
            _isChatLoading.value = true
            _errorMessage.value = null
            
            // Increment daily count on successful trigger
            _dailyQueryCount.value = _dailyQueryCount.value + 1

            // Setup temporary user-appended message stream representation
            val tempUserMessage = ChatMessage(
                id = "temp-user-id",
                role = "user",
                content = promptText,
                timestamp = Date()
            )
            _messages.value = _messages.value + tempUserMessage

            var aggregatedResponseText = ""

            repository.sendMessageStream(userId, currentSessionId, promptText, imageBytes, imageMime)
                .collect { response ->
                    when (response) {
                        is StreamResponse.SessionInitialized -> {
                            _activeSessionId.value = response.sessionId
                        }
                        is StreamResponse.ContentChunk -> {
                            aggregatedResponseText += response.text
                            // Update assistant stream response in list dynamically
                            val tempAssistantMessage = ChatMessage(
                                id = "temp-assistant-id",
                                role = "assistant",
                                content = aggregatedResponseText,
                                timestamp = Date()
                            )
                            // Remove temporary user and update list with real records
                            _messages.value = _messages.value.filter { it.id != "temp-assistant-id" } + tempAssistantMessage
                        }
                        is StreamResponse.TokenMetrics -> {
                            _promptTokens.value = response.prompt
                            _candidateTokens.value = response.candidates
                        }
                        is StreamResponse.Error -> {
                            _errorMessage.value = "Backend request failed: ${response.throwable.localizedMessage}"
                        }
                    }
                }
            _isChatLoading.value = false
        }
    }

    /**
     * Rename active chat session.
     */
    fun renameSession(sessionId: String, newTitle: String) {
        viewModelScope.launch {
            try {
                repository.renameChatSession(sessionId, newTitle)
            } catch (e: Exception) {
                _errorMessage.value = "Rename failed: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Delete active chat session.
     */
    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            try {
                repository.deleteChatSession(sessionId)
                if (_activeSessionId.value == sessionId) {
                    _activeSessionId.value = null
                }
            } catch (e: Exception) {
                _errorMessage.value = "Delete failed: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Starts voice transcription. Uses speech dictation simulation due to sandboxed environment.
     */
    fun startVoiceDictation() {
        viewModelScope.launch {
            _voiceRecordingState.value = "recording"
            kotlinx.coroutines.delay(3500) // Simulate user speech duration
            _voiceRecordingState.value = "transcribing"
            kotlinx.coroutines.delay(1500) // Simulate transcription engine processing
            
            _voiceRecordingState.value = "idle"
            sendMessage("Draft a follow-up email response to our real-estate lead confirming the upcoming open house schedules.")
        }
    }

    fun selectSession(sessionId: String?) {
        _activeSessionId.value = sessionId
    }

    fun dismissError() {
        _errorMessage.value = null
    }
}
