package com.aura.ai.billing.viewmodel

import com.aura.ai.billing.model.*
import com.aura.ai.billing.repository.BillingPurchaseResult
import com.aura.ai.billing.repository.BillingRepository
import com.aura.ai.billing.repository.PromoValidationResult
import com.aura.ai.billing.repository.RestoreResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * Clean Architecture + MVVM Compliant ViewModel managing Subscription, Billing, and Revenue states.
 */
class BillingViewModel(
    private val billingRepository: BillingRepository,
    private val userId: String
) {
    private val viewModelScope = CoroutineScope(Dispatchers.Main)

    // User Subscription state observer
    private val _subscriptionState = MutableStateFlow(UserSubscriptionState(userId = userId))
    val subscriptionState: StateFlow<UserSubscriptionState> = _subscriptionState.asStateFlow()

    // Available subscription plans list
    val subscriptionPlans: List<SubscriptionPlan> = billingRepository.getSubscriptionPlans()

    // Active invoice historical records state
    private val _invoiceHistory = MutableStateFlow<List<Invoice>>(emptyList())
    val invoiceHistory: StateFlow<List<Invoice>> = _invoiceHistory.asStateFlow()

    // Interactive coupon validations feedback
    private val _promoStatus = MutableStateFlow<PromoValidationResult?>(null)
    val promoStatus: StateFlow<PromoValidationResult?> = _promoStatus.asStateFlow()

    // Purchase progress loader indicator
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // One-shot events for subscription operation updates (Toast messages)
    private val _billingEvent = MutableSharedFlow<String>()
    val billingEvent: SharedFlow<String> = _billingEvent.asSharedFlow()

    init {
        observeSubscription()
        observeInvoices()
    }

    private fun observeSubscription() {
        viewModelScope.launch {
            billingRepository.getSubscriptionState(userId)
                .catch { e ->
                    _billingEvent.emit("Error loading subscription: ${e.localizedMessage}")
                }
                .collect { state ->
                    _subscriptionState.value = state
                }
        }
    }

    private fun observeInvoices() {
        viewModelScope.launch {
            billingRepository.getPaymentHistory(userId)
                .catch { e ->
                    _billingEvent.emit("Error retrieving payment logs: ${e.localizedMessage}")
                }
                .collect { logs ->
                    _invoiceHistory.value = logs
                }
        }
    }

    /**
     * Executes Google Play Billing purchase flow for a specified subscription SKU.
     */
    fun startPurchaseFlow(activity: Any, planId: String, period: BillingPeriod, coupon: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            billingRepository.purchaseSubscription(activity, planId, period, coupon)
                .collect { result ->
                    when (result) {
                        is BillingPurchaseResult.LaunchSuccess -> {
                            _billingEvent.emit("Google Play billing flow initiated...")
                        }
                        is BillingPurchaseResult.Success -> {
                            _billingEvent.emit("Play transaction completed. Verifying receipt...")
                            val success = billingRepository.verifyAndSyncPurchase(userId, result.receipt)
                            _isLoading.value = false
                            if (success) {
                                _billingEvent.emit("Subscription active! Premium features unlocked.")
                            } else {
                                _billingEvent.emit("Verification error. Re-trigger receipt synchronization.")
                            }
                        }
                        is BillingPurchaseResult.UserCancelled -> {
                            _isLoading.value = false
                            _billingEvent.emit("Transaction cancelled by user.")
                        }
                        is BillingPurchaseResult.Error -> {
                            _isLoading.value = false
                            _billingEvent.emit("Purchase error: ${result.throwable.localizedMessage}")
                        }
                    }
                }
        }
    }

    /**
     * Validates promotional voucher code eligibility.
     */
    fun applyCoupon(code: String) {
        if (code.isBlank()) {
            _promoStatus.value = PromoValidationResult.Invalid("Promo code field cannot be empty.")
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            val result = billingRepository.validatePromoCode(userId, code)
            _isLoading.value = false
            _promoStatus.value = result
            when (result) {
                is PromoValidationResult.Valid -> {
                    _billingEvent.emit("Promo applied: ${result.discountPercent}% off activated!")
                }
                is PromoValidationResult.Invalid -> {
                    _billingEvent.emit("Coupon rejected: ${result.reason}")
                }
            }
        }
    }

    /**
     * Cancels the active subscription renewal cycle.
     */
    fun cancelActiveSubscription() {
        viewModelScope.launch {
            _isLoading.value = true
            val success = billingRepository.cancelSubscription(userId)
            _isLoading.value = false
            if (success) {
                _billingEvent.emit("Subscription auto-renew disabled successfully.")
            } else {
                _billingEvent.emit("Unable to process cancellation. Try again.")
            }
        }
    }

    /**
     * Triggers Play Store local transaction restore checks.
     */
    fun restoreUserPurchases() {
        viewModelScope.launch {
            _isLoading.value = true
            billingRepository.restorePurchases(userId)
                .collect { result ->
                    _isLoading.value = false
                    when (result) {
                        is RestoreResult.Restored -> {
                            _billingEvent.emit("Restored active ${result.tier} subscription tier!")
                        }
                        is RestoreResult.NoActivePurchasesFound -> {
                            _billingEvent.emit("No previous transactions found for this Google Account.")
                        }
                        is RestoreResult.Error -> {
                            _billingEvent.emit("Restore failed: ${result.throwable.localizedMessage}")
                        }
                    }
                }
        }
    }

    /**
     * Quick usage check utility to determine if user exceeded capabilities on the Free Plan.
     */
    fun isFeatureAccessible(requiredTier: SubscriptionTier, currentUsage: Int, maxLimit: Int): Boolean {
        val currentTier = _subscriptionState.value.tier
        if (currentTier == SubscriptionTier.FREE && requiredTier != SubscriptionTier.FREE) {
            return currentUsage < maxLimit
        }
        return true // Paid tier has unlimited unlock on SaaS features
    }
}
