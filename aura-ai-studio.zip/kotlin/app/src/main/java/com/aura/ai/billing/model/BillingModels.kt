package com.aura.ai.billing.model

import java.util.Date

/**
 * Defines the subscription tiers available for Aura AI Studio.
 */
enum class SubscriptionTier {
    FREE,
    PRO,
    BUSINESS,
    ENTERPRISE
}

/**
 * Defines the billing frequencies.
 */
enum class BillingPeriod {
    MONTHLY,
    YEARLY
}

/**
 * Represents a premium SaaS subscription plan details.
 */
data class SubscriptionPlan(
    val id: String,
    val tier: SubscriptionTier,
    val name: String,
    val priceMonthly: Double,
    val priceYearly: Double,
    val trialDays: Int,
    val features: List<String>,
    val limits: UsageLimits
)

/**
 * Defines usage limitations.
 */
data class UsageLimits(
    val maxAiChats: Int,
    val maxVoiceMinutes: Int,
    val maxCrmRecords: Int,
    val maxCloudStorageMb: Int,
    val priorityProcessing: Boolean,
    val teamCollaboration: Boolean,
    val advancedAnalytics: Boolean
)

/**
 * Represents a secure Google Play Billing v7 transaction receipt.
 */
data class PurchaseReceipt(
    val purchaseId: String,
    val orderId: String?,
    val planId: String,
    val purchaseTime: Long,
    val purchaseState: Int, // 0 = UNSPECIFIED, 1 = PURCHASED, 2 = PENDING
    val autoRenewing: Boolean,
    val developerPayload: String?,
    val purchaseToken: String,
    val signature: String,
    val verifiedOnServer: Boolean = false
)

/**
 * Represents a simulated invoice generated upon successful charge.
 */
data class Invoice(
    val id: String,
    val invoiceNumber: String,
    val amount: Double,
    val date: Date,
    val status: String, // "Paid" or "Pending"
    val planName: String,
    val billingPeriod: String,
    val pdfUrl: String
)

/**
 * Encapsulates the user's current subscription status compiled from Firestore & billing.
 */
data class UserSubscriptionState(
    val userId: String,
    val tier: SubscriptionTier = SubscriptionTier.FREE,
    val isActive: Boolean = false,
    val period: BillingPeriod = BillingPeriod.MONTHLY,
    val expiresAt: Date? = null,
    val isTrial: Boolean = false,
    val purchaseToken: String? = null,
    val orderId: String? = null,
    val isCancelled: Boolean = false,
    val activeCouponCode: String? = null,
    val discountPercent: Int = 0
)
