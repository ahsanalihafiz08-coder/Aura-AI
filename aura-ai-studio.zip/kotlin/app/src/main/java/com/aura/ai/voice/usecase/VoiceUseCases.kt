package com.aura.ai.voice.usecase

import com.aura.ai.voice.model.*
import com.aura.ai.voice.repository.VoiceAgentRepository
import com.aura.ai.voice.repository.VoiceExchangeResult
import kotlinx.coroutines.flow.Flow

/**
 * UseCase to handle initialization of an active voice call.
 */
class StartVoiceSessionUseCase(private val repository: VoiceAgentRepository) {
    suspend operator fun invoke(userId: String, settings: VoiceSettings): VoiceSession {
        return repository.startVoiceSession(userId, settings)
    }
}

/**
 * UseCase to handle finishing and saving voice conversations in Firestore.
 */
class SaveVoiceSessionUseCase(private val repository: VoiceAgentRepository) {
    suspend operator fun invoke(session: VoiceSession, messages: List<VoiceMessage>) {
        repository.saveVoiceSession(session, messages)
    }
}

/**
 * UseCase to process live audio transactions, returning transcribed texts and synthesized voice arrays.
 */
class ProcessVoiceExchangeUseCase(private val repository: VoiceAgentRepository) {
    suspend operator fun invoke(
        userId: String,
        sessionId: String,
        userSpeechInput: String,
        settings: VoiceSettings,
        conversationHistory: List<VoiceMessage>
    ): Flow<VoiceExchangeResult> {
        return repository.processVoiceExchange(userId, sessionId, userSpeechInput, settings, conversationHistory)
    }
}

/**
 * UseCase to request high-quality campaign outbound scripts via Gemini.
 */
class GenerateCallScriptUseCase(private val repository: VoiceAgentRepository) {
    suspend operator fun invoke(
        prompt: String,
        mode: AssistantMode,
        language: String
    ): CallScript {
        return repository.generateCallScript(prompt, mode, language)
    }
}
