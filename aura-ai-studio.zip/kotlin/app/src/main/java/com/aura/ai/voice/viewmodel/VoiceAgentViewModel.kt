package com.aura.ai.voice.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aura.ai.voice.model.*
import com.aura.ai.voice.repository.VoiceExchangeResult
import com.aura.ai.voice.usecase.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Date
import java.util.UUID

class VoiceAgentViewModel(
    private val startVoiceSessionUseCase: StartVoiceSessionUseCase,
    private val saveVoiceSessionUseCase: SaveVoiceSessionUseCase,
    private val processVoiceExchangeUseCase: ProcessVoiceExchangeUseCase,
    private val generateCallScriptUseCase: GenerateCallScriptUseCase,
    private val userId: String
) : ViewModel() {

    // Main MVVM State Flows backed by Jetpack Compose
    private val _currentSession = MutableStateFlow<VoiceSession?>(null)
    val currentSession: StateFlow<VoiceSession?> = _currentSession.asStateFlow()

    private val _settings = MutableStateFlow(VoiceSettings())
    val settings: StateFlow<VoiceSettings> = _settings.asStateFlow()

    private val _transcripts = MutableStateFlow<List<VoiceMessage>>(emptyList())
    val transcripts: StateFlow<List<VoiceMessage>> = _transcripts.asStateFlow()

    private val _voiceStatus = MutableStateFlow("Idle") // Idle, Connecting, Listening, Speaking, Interrupted
    val voiceStatus: StateFlow<String> = _voiceStatus.asStateFlow()

    private val _waveforms = MutableStateFlow(List(12) { 15 })
    val waveforms: StateFlow<List<Int>> = _waveforms.asStateFlow()

    private val _micPermissionGranted = MutableStateFlow(false)
    val micPermissionGranted: StateFlow<Boolean> = _micPermissionGranted.asStateFlow()

    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _activeCallScript = MutableStateFlow<CallScript?>(null)
    val activeCallScript: StateFlow<CallScript?> = _activeCallScript.asStateFlow()

    private val _isBargeInActive = MutableStateFlow(false)
    val isBargeInActive: StateFlow<Boolean> = _isBargeInActive.asStateFlow()

    // Tracking active asynchronous operations
    private var speakJob: Job? = null
    private var waveformJob: Job? = null
    private var callTimerJob: Job? = null
    private var currentCallDurationSeconds = 0

    init {
        // Mock checking network connectivity
        viewModelScope.launch {
            delay(1000)
            _isOffline.value = false // Standard state
        }
    }

    /**
     * Set permission grant status from UI layer.
     */
    fun setMicPermissionGranted(granted: Boolean) {
        _micPermissionGranted.value = granted
    }

    /**
     * Start or Hang-Up active simulated calls.
     */
    fun toggleCall() {
        if (_currentSession.value == null) {
            startCall()
        } else {
            endCall()
        }
    }

    private fun startCall() {
        if (!_micPermissionGranted.value) {
            _errorMessage.value = "Microphone permission is required to launch vocal CRM calls."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _voiceStatus.value = "Connecting..."

            try {
                val session = startVoiceSessionUseCase(userId, _settings.value)
                _currentSession.value = session
                _transcripts.value = emptyList()
                _voiceStatus.value = "Listening"
                
                startCallTimer()
                startWaveformAnimation()

                // Dispatch intro greeting automatically based on assistant mode
                val greetPrompt = when (_settings.value.mode) {
                    AssistantMode.BUSINESS_SALES -> "System Greeting: Introduce sales metrics"
                    AssistantMode.APPOINTMENT_BOOKING -> "System Greeting: Schedule confirmation slots"
                    AssistantMode.CUSTOMER_SUPPORT -> "System Greeting: Greet for technical support"
                }
                processSpeechInput(greetPrompt, isGreeting = true)

            } catch (e: Exception) {
                _voiceStatus.value = "Idle"
                _errorMessage.value = "Failed to open voice line: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun endCall() {
        val session = _currentSession.value ?: return
        
        viewModelScope.launch {
            _isLoading.value = true
            _voiceStatus.value = "Idle"
            
            cancelActiveSpeechAndAnimation()
            callTimerJob?.cancel()

            try {
                val finalizedSession = session.copy(durationSeconds = currentCallDurationSeconds)
                saveVoiceSessionUseCase(finalizedSession, _transcripts.value)
                _currentSession.value = null
                currentCallDurationSeconds = 0
            } catch (e: Exception) {
                _errorMessage.value = "Error preserving call session logs: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Process verbal inputs. Features barge-in (interruption) detection:
     * If the user speaks while the AI agent is speaking, the AI's active audio playing
     * is cancelled immediately to accommodate the caller's priority.
     */
    fun processSpeechInput(userInput: String, isGreeting: Boolean = false) {
        val session = _currentSession.value ?: return

        // Barge-in check: user interrupts active speak job
        if (!isGreeting && speakJob?.isActive == true) {
            speakJob?.cancel()
            _isBargeInActive.value = true
            _voiceStatus.value = "Interrupted"
            
            val systemLog = VoiceMessage(
                id = UUID.randomUUID().toString(),
                role = "system",
                content = "[Caller Interrupted Assistant Speaking]",
                timestamp = Date()
            )
            _transcripts.value = _transcripts.value + systemLog
        }

        speakJob = viewModelScope.launch {
            _errorMessage.value = null
            
            if (!isGreeting) {
                val userMsg = VoiceMessage(
                    id = UUID.randomUUID().toString(),
                    role = "caller",
                    content = userInput,
                    timestamp = Date()
                )
                _transcripts.value = _transcripts.value + userMsg
            }

            _voiceStatus.value = "Listening..."
            delay(300) // Small speech processing buffer

            val history = _transcripts.value
            _voiceStatus.value = "Speaking"
            _isBargeInActive.value = false

            var currentAgentMsgId = UUID.randomUUID().toString()
            var currentAgentContent = ""

            processVoiceExchangeUseCase(userId, session.id, userInput, _settings.value, history)
                .catch { err ->
                    _errorMessage.value = "Speech synthesis error: ${err.localizedMessage}"
                }
                .collect { result ->
                    when (result) {
                        is VoiceExchangeResult.UserTranscription -> {
                            // Already handled or synced
                        }
                        is VoiceExchangeResult.AgentResponseChunk -> {
                            currentAgentContent += " " + result.textChunk
                            val updatedMsg = VoiceMessage(
                                id = currentAgentMsgId,
                                role = "agent",
                                content = currentAgentContent.trim(),
                                timestamp = Date()
                            )
                            _transcripts.value = _transcripts.value.filter { it.id != currentAgentMsgId } + updatedMsg
                        }
                        is VoiceExchangeResult.FinalResponse -> {
                            _voiceStatus.value = "Listening"
                        }
                        is VoiceExchangeResult.Error -> {
                            _errorMessage.value = "Speech synthesis failed: ${result.throwable.localizedMessage}"
                            _voiceStatus.value = "Listening"
                        }
                    }
                }
        }
    }

    /**
     * Generates custom, production-ready call script templates.
     */
    fun generateScript(prompt: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val script = generateCallScriptUseCase(prompt, _settings.value.mode, _settings.value.language)
                _activeCallScript.value = script
            } catch (e: Exception) {
                _errorMessage.value = "Call script generation failed: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Adjust vocal configurations in real-time.
     */
    fun updateVoiceSettings(speed: Float, pitch: Float, language: String, mode: AssistantMode) {
        _settings.value = VoiceSettings(speed, pitch, language, mode)
    }

    fun clearError() {
        _errorMessage.value = null
    }

    private fun startCallTimer() {
        callTimerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                currentCallDurationSeconds++
            }
        }
    }

    private fun startWaveformAnimation() {
        waveformJob = viewModelScope.launch {
            while (isActive) {
                delay(100)
                if (_voiceStatus.value == "Speaking") {
                    // Wide fluctuation
                    _waveforms.value = List(12) { (30..95).random() }
                } else if (_voiceStatus.value == "Listening...") {
                    // Small ambient hums
                    _waveforms.value = List(12) { (10..35).random() }
                } else {
                    // Quiet rest lines
                    _waveforms.value = List(12) { 15 }
                }
            }
        }
    }

    private fun cancelActiveSpeechAndAnimation() {
        speakJob?.cancel()
        waveformJob?.cancel()
        _waveforms.value = List(12) { 15 }
    }

    override fun onCleared() {
        super.onCleared()
        cancelActiveSpeechAndAnimation()
        callTimerJob?.cancel()
    }
}
