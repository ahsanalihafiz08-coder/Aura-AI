package com.aura.ai.billing.repository

import com.aura.ai.billing.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Interface detailing all operations for Subscription, Billing, and Revenue System (Phase 8).
 */
interface BillingRepository {

    /**
     * Observes the user's current subscription status from Firestore.
     */
    fun getSubscriptionState(userId: String): Flow<UserSubscriptionState>

    /**
     * Retrieves the available SaaS subscription plan metadata.
     */
    fun getSubscriptionPlans(): List<SubscriptionPlan>

    /**
     * Initiates the Google Play Billing purchase flow.
     * @param activity The active Android Activity required to host Play Dialogs.
     * @param planId The product ID or subscription SKU.
     * @param period Monthly or Yearly billing cycle.
     * @param couponCode Optional promotional discount code.
     */
    fun purchaseSubscription(
        activity: Any,
        planId: String,
        period: BillingPeriod,
        couponCode: String? = null
    ): Flow<BillingPurchaseResult>

    /**
     * Performs a secure server-side verification of Google Play purchase receipt.
     */
    suspend fun verifyAndSyncPurchase(userId: String, receipt: PurchaseReceipt): Boolean

    /**
     * Cancels an active subscription (deactivates auto-renew in Google Play/Stripe).
     */
    suspend fun cancelSubscription(userId: String): Boolean

    /**
     * Queries Google Play Billing cache and restores previously bought subscriptions.
     */
    fun restorePurchases(userId: String): Flow<RestoreResult>

    /**
     * Observes historical invoices for the user.
     */
    fun getPaymentHistory(userId: String): Flow<List<Invoice>>

    /**
     * Validates and registers a coupon or promo code.
     */
    suspend fun validatePromoCode(userId: String, code: String): PromoValidationResult
}

/**
 * Encapsulates outcomes for Billing purchase flow.
 */
sealed class BillingPurchaseResult {
    object LaunchSuccess : BillingPurchaseResult()
    data class Success(val receipt: PurchaseReceipt) : BillingPurchaseResult()
    data class UserCancelled(val message: String) : BillingPurchaseResult()
    data class Error(val throwable: Throwable) : BillingPurchaseResult()
}

/**
 * Encapsulates restore outcomes.
 */
sealed class RestoreResult {
    data class Restored(val tier: SubscriptionTier) : RestoreResult()
    object NoActivePurchasesFound : RestoreResult()
    data class Error(val throwable: Throwable) : RestoreResult()
}

/**
 * Encapsulates promo validation results.
 */
sealed class PromoValidationResult {
    data class Valid(val code: String, val discountPercent: Int) : PromoValidationResult()
    data class Invalid(val reason: String) : PromoValidationResult()
}
