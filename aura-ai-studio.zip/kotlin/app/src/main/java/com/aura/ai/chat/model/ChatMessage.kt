package com.aura.ai.chat.model

import java.util.Date

/**
 * Represents an individual message in the AI Chat Assistant conversation.
 */
data class ChatMessage(
    val id: String = "",
    val role: String = "user", // "user" or "assistant"
    val content: String = "",
    val timestamp: Date = Date(),
    val imageUri: String? = null,
    val imageMimeType: String? = null,
    val promptTokens: Int = 0,
    val candidateTokens: Int = 0
)

/**
 * Represents a stored conversation room/session in Firestore.
 */
data class ChatSession(
    val id: String = "",
    val title: String = "New Conversation",
    val userId: String = "",
    val lastMessageTime: Date = Date(),
    val subscriptionTier: String = "Starter"
)
