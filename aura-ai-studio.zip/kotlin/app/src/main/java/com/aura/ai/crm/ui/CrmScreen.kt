package com.aura.ai.crm.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.ai.crm.model.*
import com.aura.ai.crm.viewmodel.CrmViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrmScreen(
    viewModel: CrmViewModel,
    onBackClick: () -> Unit
) {
    val leads by viewModel.leads.collectAsState()
    val meetings by viewModel.meetings.collectAsState()
    val selectedLead by viewModel.selectedLead.collectAsState()
    val tasks by viewModel.selectedLeadTasks.collectAsState()
    val notes by viewModel.selectedLeadNotes.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val statusFilter by viewModel.statusFilter.collectAsState()
    val typeFilter by viewModel.typeFilter.collectAsState()
    val isKanbanView by viewModel.isKanbanView.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    val generatedEmail by viewModel.generatedEmail.collectAsState()
    val generatedWhatsApp by viewModel.generatedWhatsApp.collectAsState()

    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    val currencyFormatter = remember { NumberFormat.getCurrencyInstance(Locale.US) }

    var showCreateDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showScheduleMeetingDialog by remember { mutableStateOf(false) }
    var showAddTaskDialog by remember { mutableStateOf(false) }

    // Dropdown filters
    var showStatusFilterDropdown by remember { mutableStateOf(false) }
    var showTypeFilterDropdown by remember { mutableStateOf(false) }

    // Filter leads matching query + sidebar controls
    val filteredLeads = remember(leads, searchQuery, statusFilter, typeFilter) {
        leads.filter { lead ->
            val matchQuery = lead.name.contains(searchQuery, ignoreCase = true) ||
                    lead.company.contains(searchQuery, ignoreCase = true) ||
                    lead.industry.contains(searchQuery, ignoreCase = true)
            val matchStatus = statusFilter == null || lead.status == statusFilter
            val matchType = typeFilter == null || lead.type == typeFilter
            matchQuery && matchStatus && matchType
        }
    }

    // Pipeline Analytics Metrics
    val totalValue = remember(leads) { leads.sumOf { it.value } }
    val averageAiScore = remember(leads) {
        val scored = leads.filter { it.aiScore > 0 }
        if (scored.isNotEmpty()) scored.map { it.aiScore }.average().toInt() else 0
    }
    val hotLeadsCount = remember(leads) { leads.count { it.type == LeadType.HOT } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "AURA SMART CO-PILOT CRM",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color.Green)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ROLE: ${viewModel.userRole.name} • REAL-TIME FIRESTORE SYNC",
                                fontSize = 8.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Export CSV Trigger
                    IconButton(onClick = {
                        val csv = viewModel.exportLeadsToCsv()
                        viewModel.addLeadNote("", "Exported CRM context snapshot with ${leads.size} leads successfully.")
                    }) {
                        Icon(Icons.Default.Download, contentDescription = "Export CSV", tint = MaterialTheme.colorScheme.primary)
                    }
                    // Import CSV Trigger
                    IconButton(onClick = { showImportDialog = true }) {
                        Icon(Icons.Default.UploadFile, contentDescription = "Import CSV", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showCreateDialog = true }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add Lead", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC))
                .padding(12.dp)
        ) {
            // Error handling banner
            errorMessage?.let { err ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = Color.Red, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = err,
                            fontSize = 11.sp,
                            color = Color(0xFF991B1B),
                            modifier = Modifier.weight(1f),
                            lineHeight = 14.sp
                        )
                        IconButton(onClick = { viewModel.clearError() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color(0xFF991B1B), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            // SECTION 1: CRM KPIs & Analytics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Card 1: Total Value
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("PIPELINE VALUE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currencyFormatter.format(totalValue),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A)
                        )
                    }
                }
                // Card 2: Avg AI Match Score
                Card(
                    modifier = Modifier.weight(0.9f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("AVG AI QUALITY", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "Score", tint = Color(0xFF6366F1), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$averageAiScore%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF6366F1)
                            )
                        }
                    }
                }
                // Card 3: Hot Leads
                Card(
                    modifier = Modifier.weight(0.9f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("HOT CONVERSIONS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalFireDepartment, contentDescription = "Hot", tint = Color(0xFFEF4444), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$hotLeadsCount leads",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFEF4444)
                            )
                        }
                    }
                }
            }

            // SECTION 2: Interactive Controls, Filters, View Modes
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search CRM leads, industry, company...", fontSize = 11.sp, color = Color.LightGray) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(16.dp)) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedIndicatorColor = MaterialTheme.colorScheme.primary
                    )
                )

                // Toggle Kanban Board vs List view
                IconButton(
                    onClick = { viewModel.toggleViewMode() },
                    modifier = Modifier
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .size(44.dp)
                ) {
                    Icon(
                        imageVector = if (isKanbanView) Icons.Default.List else Icons.Default.Dashboard,
                        contentDescription = "Toggle Kanban Board view",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // SECTION 3: Main CRM Views Grid (Kanban Board vs Standard Filtered List)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (isKanbanView) {
                    // Robust Kanban Board Layout spanning columns based on LeadStatus
                    val columns = LeadStatus.values()
                    LazyRow(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(columns) { columnStatus ->
                            val columnLeads = leads.filter { it.status == columnStatus }
                            Card(
                                modifier = Modifier
                                    .width(260.dp)
                                    .fillMaxHeight(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(8.dp)
                                ) {
                                    // Column Title Header
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = columnStatus.label.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color(0xFF475569)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .background(Color.White, CircleShape)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = columnLeads.size.toString(),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF475569)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Column Kanban Lead Stack
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(columnLeads) { lead ->
                                            Card(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { viewModel.selectLead(lead) },
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (selectedLead?.id == lead.id) Color(0xFFEEF2FF) else Color.White
                                                ),
                                                border = if (selectedLead?.id == lead.id) BorderStroke(1.dp, Color(0xFF818CF8)) else null,
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = lead.company.uppercase(),
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Black,
                                                            color = Color.Gray,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        if (lead.isHighPriority) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .background(Color(0xFFFEF2F2), RoundedCornerShape(4.dp))
                                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                                            ) {
                                                                Text("HIGH PRIORITY", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                                                            }
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(4.dp))

                                                    Text(
                                                        text = lead.name,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF1E293B)
                                                    )

                                                    Spacer(modifier = Modifier.height(6.dp))

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = currencyFormatter.format(lead.value),
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Black,
                                                            color = Color(0xFF0F172A)
                                                        )
                                                        if (lead.aiScore > 0) {
                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = Color(0xFF6366F1), modifier = Modifier.size(10.dp))
                                                                Spacer(modifier = Modifier.width(2.dp))
                                                                Text("${lead.aiScore}%", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6366F1))
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Dual panel/list layout when in Standard mode
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Left Panel: Lead List Column
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (filteredLeads.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(200.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("No CRM leads match criteria.", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            } else {
                                items(filteredLeads) { lead ->
                                    val isSelected = selectedLead?.id == lead.id
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.selectLead(lead) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) Color(0xFFEEF2FF) else Color.White
                                        ),
                                        border = if (isSelected) BorderStroke(1.dp, Color(0xFF818CF8)) else null
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = lead.name,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF1E293B)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Box(
                                                        modifier = Modifier
                                                            .background(
                                                                if (lead.type == LeadType.HOT) Color(0xFFFEE2E2) else Color(0xFFF1F5F9),
                                                                RoundedCornerShape(4.dp)
                                                            )
                                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                                    ) {
                                                        Text(
                                                            text = lead.type.label.uppercase(),
                                                            fontSize = 7.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (lead.type == LeadType.HOT) Color.Red else Color.Gray
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "${lead.company} • ${lead.industry}",
                                                    fontSize = 9.sp,
                                                    color = Color.Gray
                                                )
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = currencyFormatter.format(lead.value),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = Color(0xFF0F172A)
                                                )
                                                if (lead.aiScore > 0) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = Color(0xFF6366F1), modifier = Modifier.size(9.dp))
                                                        Spacer(modifier = Modifier.width(2.dp))
                                                        Text("${lead.aiScore}%", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6366F1))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Right Panel: Selected Lead Detailed Customer Card & Action Dashboard
                        Box(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight()
                        ) {
                            selectedLead?.let { activeLead ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Panel 1: Customer Profile header
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.Top
                                            ) {
                                                Column {
                                                    Text(text = activeLead.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                    Text(text = activeLead.company, fontSize = 10.sp, color = Color.Gray)
                                                }
                                                IconButton(
                                                    onClick = { viewModel.removeLead(activeLead.id) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Purge Lead", tint = Color.Red, modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))
                                            Divider(color = Color(0xFFF1F5F9))
                                            Spacer(modifier = Modifier.height(8.dp))

                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color(0xFFEEF2FF), RoundedCornerShape(6.dp))
                                                        .clickable { viewModel.updateLeadStatus(activeLead.id, LeadStatus.CONTACTED) }
                                                        .padding(vertical = 4.dp, horizontal = 8.dp)
                                                ) {
                                                    Text("Move to Contacted", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4F46E5))
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color(0xFFFEF3C7), RoundedCornerShape(6.dp))
                                                        .clickable { viewModel.updateLeadType(activeLead.id, LeadType.HOT) }
                                                        .padding(vertical = 4.dp, horizontal = 8.dp)
                                                ) {
                                                    Text("Mark Hot Pipeline", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                                                }
                                            }
                                        }
                                    }

                                    // Panel 2: AI Automation Insight & Smart Recommendations
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.AutoAwesome, contentDescription = "AI Panel", tint = Color(0xFF6366F1), modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("AURA AI BUSINESS AUTOMATION", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color(0xFF4F46E5))
                                                }
                                                Button(
                                                    onClick = { viewModel.triggerAiQualification(activeLead.id) },
                                                    shape = RoundedCornerShape(8.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(24.dp)
                                                ) {
                                                    Text("Qualify", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(10.dp))

                                            // Smart qualification indicator
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("QUALIFICATION FIT SCORE: ", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                Text(
                                                    text = if (activeLead.aiScore > 0) "${activeLead.aiScore}%" else "Uncalibrated",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = if (activeLead.aiScore >= 75) Color(0xFF16A34A) else Color(0xFF4F46E5)
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            Text("CONVERSATION AI SUMMARY:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                            Text(
                                                text = activeLead.aiSummary,
                                                fontSize = 9.sp,
                                                lineHeight = 13.sp,
                                                color = Color(0xFF334155),
                                                modifier = Modifier.padding(bottom = 6.dp)
                                            )

                                            Text("AI RECOMMENDATION:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                            Text(
                                                text = activeLead.nextActionRecommendation,
                                                fontSize = 9.sp,
                                                lineHeight = 13.sp,
                                                color = Color(0xFF334155)
                                            )

                                            Spacer(modifier = Modifier.height(10.dp))
                                            Divider(color = Color(0xFFE2E8F0))
                                            Spacer(modifier = Modifier.height(10.dp))

                                            // Email & WhatsApp Copys Generation triggers
                                            var emailGoalInput by remember { mutableStateOf("Enterprise software pilot") }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                OutlinedTextField(
                                                    value = emailGoalInput,
                                                    onValueChange = { emailGoalInput = it },
                                                    placeholder = { Text("Goal/Offer...", fontSize = 9.sp) },
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(36.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 9.sp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                IconButton(
                                                    onClick = { viewModel.generateEmailTemplate(activeLead.id, emailGoalInput) },
                                                    modifier = Modifier
                                                        .background(Color(0xFFEFF6FF), RoundedCornerShape(8.dp))
                                                        .size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.MailOutline, contentDescription = "Email", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                                }
                                                Spacer(modifier = Modifier.width(4.dp))
                                                IconButton(
                                                    onClick = { viewModel.generateWhatsAppTemplate(activeLead.id, emailGoalInput) },
                                                    modifier = Modifier
                                                        .background(Color(0xFFECFDF5), RoundedCornerShape(8.dp))
                                                        .size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = "WhatsApp", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            generatedEmail?.let { mail ->
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("GENERATED OUTBOUND EMAIL:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color.White, RoundedCornerShape(8.dp))
                                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                                        .padding(8.dp)
                                                ) {
                                                    Text(text = mail, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF1E293B))
                                                }
                                            }

                                            generatedWhatsApp?.let { wa ->
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("GENERATED WHATSAPP DRIFT:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color.White, RoundedCornerShape(8.dp))
                                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                                        .padding(8.dp)
                                                ) {
                                                    Text(text = wa, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF1E293B))
                                                }
                                            }
                                        }
                                    }

                                    // Panel 3: CRM Follow-up Reminders & Task Tracker
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("CRM REMINDERS & TASKS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                                IconButton(
                                                    onClick = { showAddTaskDialog = true },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = "Add Task", modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            if (tasks.isEmpty()) {
                                                Text("No pending task triggers recorded.", fontSize = 9.sp, color = Color.Gray)
                                            } else {
                                                tasks.forEach { task ->
                                                    val isCompleted = task.status == TaskStatus.COMPLETED
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Checkbox(
                                                                checked = isCompleted,
                                                                onCheckedChange = { viewModel.toggleTaskStatus(task) },
                                                                modifier = Modifier.size(24.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Column {
                                                                Text(
                                                                    text = task.title,
                                                                    fontSize = 10.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = if (isCompleted) Color.Gray else Color(0xFF1E293B)
                                                                )
                                                                Text(
                                                                    text = "Priority: ${task.priority}",
                                                                    fontSize = 8.sp,
                                                                    color = Color.Gray
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Panel 4: Notes & Real-time Conversation Logs Timeline
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("CRM TIMELINE & CALL MEMOS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                            Spacer(modifier = Modifier.height(10.dp))

                                            var newNoteInput by remember { mutableStateOf("") }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                OutlinedTextField(
                                                    value = newNoteInput,
                                                    onValueChange = { newNoteInput = it },
                                                    placeholder = { Text("Log a customer note/call log...", fontSize = 10.sp) },
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(42.dp),
                                                    shape = RoundedCornerShape(10.dp),
                                                    textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                IconButton(
                                                    onClick = {
                                                        if (newNoteInput.trim().isNotEmpty()) {
                                                            viewModel.addLeadNote(activeLead.id, newNoteInput)
                                                            newNoteInput = ""
                                                        }
                                                    },
                                                    modifier = Modifier
                                                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                                                        .size(42.dp)
                                                ) {
                                                    Icon(Icons.Default.Send, contentDescription = "Log Note", tint = Color.White, modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))

                                            if (notes.isEmpty()) {
                                                Text("No activity timeline logs.", fontSize = 9.sp, color = Color.Gray)
                                            } else {
                                                notes.forEach { note ->
                                                    Column(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(vertical = 4.dp)
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Text(
                                                                text = "${note.type.uppercase()} BY ${note.creatorId}",
                                                                fontSize = 8.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color.Gray
                                                            )
                                                            Text(
                                                                text = dateFormatter.format(note.timestamp),
                                                                fontSize = 7.sp,
                                                                color = Color.Gray
                                                            )
                                                        }
                                                        Text(
                                                            text = note.content,
                                                            fontSize = 9.sp,
                                                            lineHeight = 13.sp,
                                                            color = Color(0xFF334155),
                                                            modifier = Modifier.padding(top = 2.dp)
                                                        )
                                                        Divider(color = Color(0xFFF1F5F9), modifier = Modifier.padding(top = 4.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Panel 5: Meeting Scheduler Component
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("CALENDAR SCHEDULER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                                IconButton(
                                                    onClick = { showScheduleMeetingDialog = true },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Schedule Meeting", modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            val leadMeetings = meetings.filter { it.leadId == activeLead.id }
                                            if (leadMeetings.isEmpty()) {
                                                Text("No scheduled demo appointments.", fontSize = 9.sp, color = Color.Gray)
                                            } else {
                                                leadMeetings.forEach { mtg ->
                                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                                        Text(mtg.title, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                        Text(
                                                            "Date: ${dateFormatter.format(mtg.dateTime)} • Loc: ${mtg.locationLink}",
                                                            fontSize = 8.sp,
                                                            color = Color.Gray
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } ?: run {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White, RoundedCornerShape(16.dp))
                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.SupervisedUserCircle, contentDescription = "Select Lead", tint = Color.Gray, modifier = Modifier.size(44.dp))
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            text = "Select a Lead from left pane\nto view detailed CRM activity timeline.",
                                            fontSize = 11.sp,
                                            color = Color.Gray,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal dialogue: Add Lead
    if (showCreateDialog) {
        var nameInput by remember { mutableStateOf("") }
        var companyInput by remember { mutableStateOf("") }
        var emailInput by remember { mutableStateOf("") }
        var phoneInput by remember { mutableStateOf("") }
        var valueInput by remember { mutableStateOf("12500") }
        var industryInput by remember { mutableStateOf("Apex Healthcare") }
        var notesInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Register CRM Lead Profile", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        placeholder = { Text("Lead Representative Name", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = companyInput,
                        onValueChange = { companyInput = it },
                        placeholder = { Text("Corporate Name", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        placeholder = { Text("Email Address", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        placeholder = { Text("Telephone Contact", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = valueInput,
                        onValueChange = { valueInput = it },
                        placeholder = { Text("Estimated Valuation ($)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = industryInput,
                        onValueChange = { industryInput = it },
                        placeholder = { Text("Industry Market Sector", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        placeholder = { Text("Initial conversation remarks...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.trim().isNotEmpty()) {
                            viewModel.addNewLead(
                                nameInput,
                                companyInput,
                                emailInput,
                                phoneInput,
                                valueInput.toDoubleOrNull() ?: 5000.0,
                                industryInput,
                                notesInput
                            )
                            showCreateDialog = false
                        }
                    }
                ) {
                    Text("Register Profile", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Dismiss", color = Color.Gray)
                }
            }
        )
    }

    // Modal dialogue: Schedule Meeting Calendar
    if (showScheduleMeetingDialog && selectedLead != null) {
        val lead = selectedLead!!
        var titleInput by remember { mutableStateOf("Corporate Platform Demonstration") }
        var descInput by remember { mutableStateOf("In-depth walkthrough of WhatsApp CRM integrations.") }
        var locationInput by remember { mutableStateOf("https://meet.google.com/xyz-abc-123") }

        AlertDialog(
            onDismissRequest = { showScheduleMeetingDialog = false },
            title = { Text("Schedule Demo Calendar", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Lead: ${lead.name} (${lead.company})", fontSize = 11.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        placeholder = { Text("Meeting Title", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        placeholder = { Text("Description", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = locationInput,
                        onValueChange = { locationInput = it },
                        placeholder = { Text("Google Meet / Office Link", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.scheduleMeeting(lead.id, titleInput, descInput, Date(System.currentTimeMillis() + 86400000), locationInput)
                        showScheduleMeetingDialog = false
                    }
                ) {
                    Text("Confirm Calendar Slot", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showScheduleMeetingDialog = false }) {
                    Text("Dismiss", color = Color.Gray)
                }
            }
        )
    }

    // Modal dialogue: Add Task
    if (showAddTaskDialog && selectedLead != null) {
        val lead = selectedLead!!
        var titleInput by remember { mutableStateOf("Follow-up outreach phone call") }
        var descInput by remember { mutableStateOf("Clarify database sync concerns with technical decision maker.") }
        var priorityInput by remember { mutableStateOf("High") }

        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("Create CRM Task Trigger", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Lead: ${lead.name}", fontSize = 11.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        placeholder = { Text("Task Title", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        placeholder = { Text("Description Details", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = priorityInput,
                        onValueChange = { priorityInput = it },
                        placeholder = { Text("Priority (Low/Medium/High)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addNewTask(lead.id, titleInput, descInput, priorityInput, Date(System.currentTimeMillis() + 86400000))
                        showAddTaskDialog = false
                    }
                ) {
                    Text("Record Task", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) {
                    Text("Dismiss", color = Color.Gray)
                }
            }
        )
    }

    // Modal dialogue: Import CSV Leads
    if (showImportDialog) {
        var csvContentInput by remember {
            mutableStateOf(
                """
                Name,Company,Email,Phone,Value,Industry
                Julio Gomez,Gomez Logistics,julio@gomezlog.com,+34 912 345 678,25000.0,Logistics & Freight
                Sophie Martin,Martin Boutique,sophie@martinboutique.fr,+33 1 23 45 67 89,9500.0,Retail & Commerce
                Oliver Krauss,Krauss Fintech,oliver@kraussfin.de,+49 89 1234567,48000.0,Finance & Tech
            """.trimIndent()
            )
        }

        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("Batch Import Campaign Leads (CSV)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Paste standard raw CSV text contents below:", fontSize = 11.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = csvContentInput,
                        onValueChange = { csvContentInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.importLeadsFromCsv(csvContentInput)
                        showImportDialog = false
                    }
                ) {
                    Text("Import Batch", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Dismiss", color = Color.Gray)
                }
            }
        )
    }
}
