package com.aura.ai.voice.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.ai.voice.model.*
import com.aura.ai.voice.viewmodel.VoiceAgentViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceAgentScreen(
    viewModel: VoiceAgentViewModel,
    onBackClick: () -> Unit
) {
    // Collect states from ViewModel
    val currentSession by viewModel.currentSession.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val transcripts by viewModel.transcripts.collectAsState()
    val voiceStatus by viewModel.voiceStatus.collectAsState()
    val waveforms by viewModel.waveforms.collectAsState()
    val micPermissionGranted by viewModel.micPermissionGranted.collectAsState()
    val isOffline by viewModel.isOffline.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val activeCallScript by viewModel.activeCallScript.collectAsState()
    val isBargeInActive by viewModel.isBargeInActive.collectAsState()

    val scope = rememberCoroutineScope()
    var scriptPromptInput by remember { mutableStateOf("") }
    val transcriptListState = rememberLazyListState()

    var showLanguageDropdown by remember { mutableStateOf(false) }
    var showPermissionRationale by remember { mutableStateOf(!micPermissionGranted) }

    // Supported locales
    val languages = remember {
        mapOf(
            "en-US" to "English (US)",
            "es-ES" to "Spanish (ES)",
            "fr-FR" to "French (FR)",
            "de-DE" to "German (DE)",
            "ja-JP" to "Japanese (JP)"
        )
    }

    // Scroll to the latest dialog bubble
    LaunchedEffect(transcripts.size) {
        if (transcripts.isNotEmpty()) {
            transcriptListState.animateScrollToItem(transcripts.size - 1)
        }
    }

    // Microphone Permission Rationale overlay dialogue
    if (showPermissionRationale) {
        AlertDialog(
            onDismissRequest = { showPermissionRationale = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Microphone",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Mic Access Required", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Text(
                    text = "Aura AI Voice Agent requires access to your microphone to transcribe verbal instructions, simulate real-time business outreach, and confirm demo appointments in real-time.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setMicPermissionGranted(true)
                        showPermissionRationale = false
                    }
                ) {
                    Text("Grant Permission", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionRationale = false }) {
                    Text("Dismiss", fontSize = 12.sp, color = Color.Gray)
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "AURA AI VOICE AUTOMATION",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isOffline) Color.Red else Color.Green)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isOffline) "OFFLINE MODE" else "5G CLOUD ENGINE STABLE",
                                fontSize = 8.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                actions = {
                    IconButton(onClick = { showPermissionRationale = true }) {
                        Icon(
                            if (micPermissionGranted) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = "Permission Status",
                            tint = if (micPermissionGranted) MaterialTheme.colorScheme.primary else Color.Red
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC)) // off-white slate background
                .padding(horizontal = 16.dp)
        ) {
            // Error Alert Bar
            errorMessage?.let { err ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    shape = RoundedCornerShape(12.dp),
                    border = border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = Color.Red, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = err,
                            fontSize = 11.sp,
                            color = Color(0xFF991B1B),
                            modifier = Modifier.weight(1f),
                            lineHeight = 14.sp
                        )
                        IconButton(onClick = { viewModel.clearError() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color(0xFF991B1B), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            // Main Layout Divided into upper call orb + settings + chat logs
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                // Section 1: Immersive Calling Panel
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (currentSession != null) "AURA ACTIVE VOICE CONNECTION" else "AURA VOICE NODE OFFLINE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (currentSession != null) MaterialTheme.colorScheme.primary else Color.Gray,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Glowing Central Voice Sphere
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            colors = if (currentSession != null) {
                                                listOf(Color(0xFFE0E7FF), Color(0xFFEEF2FF), Color.White)
                                            } else {
                                                listOf(Color(0xFFF1F5F9), Color(0xFFF8FAFC), Color.White)
                                            }
                                        )
                                    )
                                    .border(
                                        width = 1.dp,
                                        brush = Brush.sweepGradient(
                                            colors = if (currentSession != null) {
                                                listOf(Color(0xFF6366F1), Color(0xFF4F46E5), Color(0xFF6366F1))
                                            } else {
                                                listOf(Color(0xFF94A3B8), Color(0xFFCBD5E1), Color(0xFF94A3B8))
                                            }
                                        ),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (currentSession != null) Icons.Default.PhoneInTalk else Icons.Default.SettingsVoice,
                                    contentDescription = "Calling Status",
                                    tint = if (currentSession != null) Color(0xFF4F46E5) else Color(0xFF64748B),
                                    modifier = Modifier.size(44.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = voiceStatus.uppercase(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = if (currentSession != null) Color(0xFF4F46E5) else Color(0xFF334155)
                            )

                            // Animated barge-in indicator
                            if (isBargeInActive) {
                                Text(
                                    text = "✦ BARGE-IN DETECTED: AI INTERRUPTED ✦",
                                    fontSize = 9.sp,
                                    color = Color(0xFFD97706),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Sound Waveforms Visualization
                            Row(
                                modifier = Modifier
                                    .height(36.dp)
                                    .padding(horizontal = 24.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                waveforms.forEach { waveHeight ->
                                    val animatedHeight by animateIntAsState(
                                        targetValue = waveHeight,
                                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(animatedHeight.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(
                                                if (currentSession != null) Color(0xFF6366F1) else Color(0xFFCBD5E1)
                                            )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // Primary Action: Start/Stop Call
                            Button(
                                onClick = { viewModel.toggleCall() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (currentSession != null) Color(0xFFDC2626) else Color(0xFF4F46E5)
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(
                                        imageVector = if (currentSession != null) Icons.Default.CallEnd else Icons.Default.Call,
                                        contentDescription = "Toggle Call",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (currentSession != null) "HANG UP (END CALL)" else "START SALES ASSISTANT CALL",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Section 2: Real-time Dialogue Log
                if (currentSession != null || transcripts.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "LIVE SPEECH TRANSCRIPTS",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )

                                Box(modifier = Modifier.weight(1f)) {
                                    if (transcripts.isEmpty()) {
                                        Box(
                                            modifier = Modifier.fillMaxSize(),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "Awaiting first vocal input from caller...",
                                                fontSize = 11.sp,
                                                color = Color.Gray,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    } else {
                                        LazyColumn(
                                            state = transcriptListState,
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxSize()
                                        ) {
                                            items(transcripts) { msg ->
                                                when (msg.role) {
                                                    "caller" -> {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.End
                                                        ) {
                                                            Card(
                                                                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                                                                shape = RoundedCornerShape(12.dp, 0.dp, 12.dp, 12.dp),
                                                                modifier = Modifier.widthIn(max = 240.dp)
                                                            ) {
                                                                Text(
                                                                    text = msg.content,
                                                                    fontSize = 11.sp,
                                                                    modifier = Modifier.padding(10.dp),
                                                                    lineHeight = 15.sp,
                                                                    color = Color(0xFF1E40AF)
                                                                )
                                                            }
                                                        }
                                                    }
                                                    "agent" -> {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.Start
                                                        ) {
                                                            Card(
                                                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F3FF)),
                                                                shape = RoundedCornerShape(0.dp, 12.dp, 12.dp, 12.dp),
                                                                modifier = Modifier.widthIn(max = 240.dp)
                                                            ) {
                                                                Text(
                                                                    text = msg.content,
                                                                    fontSize = 11.sp,
                                                                    modifier = Modifier.padding(10.dp),
                                                                    lineHeight = 15.sp,
                                                                    color = Color(0xFF5B21B6)
                                                                )
                                                            }
                                                        }
                                                    }
                                                    "system" -> {
                                                        Text(
                                                            text = msg.content,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFD97706),
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(vertical = 4.dp),
                                                            textAlign = TextAlign.Center
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Interactive Quick-Speak buttons for Simulator
                                if (currentSession != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Button(
                                            onClick = { viewModel.processSpeechInput("Is this system secure?") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEEF2FF), contentColor = Color(0xFF4F46E5)),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("Ask Security", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = { viewModel.processSpeechInput("I'd like to book Wednesday please.") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEEF2FF), contentColor = Color(0xFF4F46E5)),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("Book Wednesday", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 3: Voice Settings Slider / Panel
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "VOICE ENGINE SETTINGS",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            // Mode Selector Tabs
                            Text(text = "ASSISTANT MODE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                AssistantMode.values().forEach { mode ->
                                    val isSelected = settings.mode == mode
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.updateVoiceSettings(
                                                    settings.speed,
                                                    settings.pitch,
                                                    settings.language,
                                                    mode
                                                )
                                            },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) Color(0xFFEEF2FF) else Color(0xFFF8FAFC)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = if (isSelected) border(1.dp, Color(0xFF818CF8), RoundedCornerShape(10.dp)) else null
                                    ) {
                                        Text(
                                            text = mode.label.split(" ")[1], // just show roles
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color(0xFF4F46E5) else Color(0xFF64748B),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Language Selector
                            Text(text = "CONVERSATION LANGUAGE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Box {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showLanguageDropdown = true },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = languages[settings.language] ?: settings.language, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", modifier = Modifier.size(16.dp))
                                    }
                                }

                                DropdownMenu(
                                    expanded = showLanguageDropdown,
                                    onDismissRequest = { showLanguageDropdown = false }
                                ) {
                                    languages.forEach { (code, name) ->
                                        DropdownMenuItem(
                                            text = { Text(name, fontSize = 11.sp) },
                                            onClick = {
                                                viewModel.updateVoiceSettings(
                                                    settings.speed,
                                                    settings.pitch,
                                                    code,
                                                    settings.mode
                                                )
                                                showLanguageDropdown = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Speed Slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "SPEECH SPEED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text(text = String.format("%.1fx", settings.speed), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4F46E5))
                            }
                            Slider(
                                value = settings.speed,
                                onValueChange = {
                                    viewModel.updateVoiceSettings(
                                        it,
                                        settings.pitch,
                                        settings.language,
                                        settings.mode
                                    )
                                },
                                valueRange = 0.5f..2.0f,
                                modifier = Modifier.height(24.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Pitch Slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "SPEECH PITCH", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text(text = String.format("%.1fx", settings.pitch), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4F46E5))
                            }
                            Slider(
                                value = settings.pitch,
                                onValueChange = {
                                    viewModel.updateVoiceSettings(
                                        settings.speed,
                                        it,
                                        settings.language,
                                        settings.mode
                                    )
                                },
                                valueRange = 0.5f..2.0f,
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }
                }

                // Section 4: Call Script Generator
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "OUTBOUND CALL SCRIPT GENERATOR",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            OutlinedTextField(
                                value = scriptPromptInput,
                                onValueChange = { scriptPromptInput = it },
                                placeholder = { Text("e.g., Apex Real Estate Outreach Campaign", fontSize = 11.sp, color = Color.LightGray) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { viewModel.generateScript(scriptPromptInput) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = "Generate", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Generate Campaign Call Script", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            activeCallScript?.let { script ->
                                Spacer(modifier = Modifier.height(16.dp))
                                Divider(color = Color(0xFFF1F5F9))
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = script.title.uppercase(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = languages[script.language]?.uppercase() ?: script.language,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Gray,
                                        modifier = Modifier
                                            .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFFAFAFA), RoundedCornerShape(12.dp))
                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = script.generatedScript,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 15.sp,
                                        color = Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
