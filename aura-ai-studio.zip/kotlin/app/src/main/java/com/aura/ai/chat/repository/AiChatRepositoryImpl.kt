package com.aura.ai.chat.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.aura.ai.chat.model.ChatMessage
import com.aura.ai.chat.model.ChatSession
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.BufferedReader
import java.util.Date
import java.util.UUID

class AiChatRepositoryImpl(
    private val firestore: FirebaseFirestore,
    private val httpClient: OkHttpClient,
    private val backendUrl: String = "https://ais-pre-sdaaeq7tvi55bqddwhgmb3-480684355229.asia-east1.run.app" // Points to Express proxy
) : AiChatRepository {

    override fun getChatSessions(userId: String): Flow<List<ChatSession>> = callbackFlow {
        val listenerRegistration = firestore.collection("ai_chats")
            .whereEqualTo("userId", userId)
            .orderBy("lastMessageTime", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val sessions = snapshot?.documents?.mapNotNull { doc ->
                    val id = doc.id
                    val title = doc.getString("title") ?: "Untitled Session"
                    val uid = doc.getString("userId") ?: ""
                    val time = doc.getDate("lastMessageTime") ?: Date()
                    ChatSession(id, title, uid, time)
                } ?: emptyList()
                trySend(sessions)
            }
        awaitClose { listenerRegistration.remove() }
    }

    override fun getMessageHistory(sessionId: String): Flow<List<ChatMessage>> = callbackFlow {
        val listenerRegistration = firestore.collection("ai_chats")
            .document(sessionId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val historyList = snapshot.get("messageHistory") as? List<Map<String, Any>>
                    val messages = historyList?.map { map ->
                        ChatMessage(
                            id = map["id"] as? String ?: UUID.randomUUID().toString(),
                            role = map["role"] as? String ?: "user",
                            content = map["content"] as? String ?: "",
                            timestamp = map["timestamp"] as? Date ?: Date(),
                            imageUri = map["image"] as? String,
                            promptTokens = (map["promptTokens"] as? Long)?.toInt() ?: 0,
                            candidateTokens = (map["candidateTokens"] as? Long)?.toInt() ?: 0
                        )
                    } ?: emptyList()
                    trySend(messages)
                } else {
                    trySend(emptyList())
                }
            }
        awaitClose { listenerRegistration.remove() }
    }

    override fun sendMessageStream(
        userId: String,
        sessionId: String?,
        message: String,
        imageBytes: ByteArray?,
        imageMime: String?
    ): Flow<StreamResponse> = callbackFlow {
        val activeSessionId = sessionId ?: UUID.randomUUID().toString()
        val isNewSession = sessionId == null

        // Write user message to local/cloud Firestore instantly for seamless offline sync
        val userMsgId = UUID.randomUUID().toString()
        val userMsg = hashMapOf(
            "id" to userMsgId,
            "role" to "user",
            "content" to message,
            "timestamp" to Date(),
            "image" to imageBytes?.let { "data:$imageMime;base64," + android.util.Base64.encodeToString(it, android.util.Base64.NO_WRAP) }
        )

        val sessionRef = firestore.collection("ai_chats").document(activeSessionId)
        
        try {
            if (isNewSession) {
                // Initialize session doc
                val initialSession = hashMapOf(
                    "userId" to userId,
                    "title" to "Aura AI Chat",
                    "lastMessageTime" to Date(),
                    "messageHistory" to listOf(userMsg)
                )
                sessionRef.set(initialSession).await()
                trySend(StreamResponse.SessionInitialized(activeSessionId, "Aura AI Chat"))
            } else {
                // Append user message to existing history list
                firestore.runTransaction { transaction ->
                    val snapshot = transaction.get(sessionRef)
                    val historyList = (snapshot.get("messageHistory") as? List<*>)?.toMutableList() ?: mutableListOf<Any>()
                    historyList.add(userMsg)
                    transaction.update(sessionRef, "messageHistory", historyList)
                    transaction.update(sessionRef, "lastMessageTime", Date())
                }.await()
            }
        } catch (e: Exception) {
            trySend(StreamResponse.Error(e))
            close(e)
            return@callbackFlow
        }

        // Build streaming HTTP Request to Node.js proxy server
        val jsonPayload = JSONObject().apply {
            put("message", message)
            put("sessionId", activeSessionId)
            put("userId", userId)
            if (imageBytes != null && imageMime != null) {
                put("image", android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP))
                put("imageMime", imageMime)
            }
        }

        val request = Request.Builder()
            .url("$backendUrl/api/assistant/chat/stream")
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "text/event-stream")
            .build()

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorMsg = response.body?.string() ?: "Unknown backend error"
                val exc = Exception("Failed streaming response: Code ${response.code}. Details: $errorMsg")
                trySend(StreamResponse.Error(exc))
                close(exc)
                return@callbackFlow
            }

            val reader = response.body?.charStream()?.let { BufferedReader(it) }
            var line: String?
            var fullAssistantContent = ""
            var finalPromptTokens = 0
            var finalCandidateTokens = 0

            try {
                while (reader?.readLine().also { line = it } != null) {
                    val currentLine = line ?: ""
                    if (currentLine.startsWith("data: ")) {
                        val rawData = currentLine.removePrefix("data: ").trim()
                        if (rawData == "[DONE]") {
                            break
                        }
                        
                        val json = JSONObject(rawData)
                        if (json.has("text")) {
                            val textChunk = json.getString("text")
                            fullAssistantContent += textChunk
                            trySend(StreamResponse.ContentChunk(textChunk))
                        }
                        if (json.has("usage")) {
                            val usage = json.getJSONObject("usage")
                            finalPromptTokens = usage.optInt("promptTokens", 0)
                            finalCandidateTokens = usage.optInt("candidatesTokens", 0)
                            trySend(StreamResponse.TokenMetrics(finalPromptTokens, finalCandidateTokens))
                        }
                    }
                }

                // Append assistant response to Firestore history list once complete
                val assistantMsg = hashMapOf(
                    "id" to UUID.randomUUID().toString(),
                    "role" to "assistant",
                    "content" to fullAssistantContent,
                    "timestamp" to Date(),
                    "promptTokens" to finalPromptTokens,
                    "candidateTokens" to finalCandidateTokens
                )

                firestore.runTransaction { transaction ->
                    val snapshot = transaction.get(sessionRef)
                    val historyList = (snapshot.get("messageHistory") as? List<*>)?.toMutableList() ?: mutableListOf<Any>()
                    historyList.add(assistantMsg)
                    transaction.update(sessionRef, "messageHistory", historyList)
                }.await()

                // Trigger title generator asynchronously in background
                triggerAutoTitleGeneration(userId, activeSessionId, message, fullAssistantContent)

            } catch (e: Exception) {
                trySend(StreamResponse.Error(e))
            }
        }
        close()
    }

    override suspend fun deleteChatSession(sessionId: String) {
        firestore.collection("ai_chats").document(sessionId).delete().await()
    }

    override suspend fun renameChatSession(sessionId: String, newTitle: String) {
        firestore.collection("ai_chats").document(sessionId).update("title", newTitle).await()
    }

    private suspend fun triggerAutoTitleGeneration(
        userId: String,
        sessionId: String,
        userPrompt: String,
        aiResponse: String
    ) {
        try {
            val jsonPayload = JSONObject().apply {
                put("userPrompt", userPrompt)
                put("assistantResponse", aiResponse)
            }
            val request = Request.Builder()
                .url("$backendUrl/api/assistant/chat/title")
                .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseJson = JSONObject(response.body?.string() ?: "{}")
                    val generatedTitle = responseJson.optString("title", "")
                    if (generatedTitle.isNotEmpty()) {
                        renameChatSession(sessionId, generatedTitle)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
