package com.aura.ai.crm.model

import java.util.Date

/**
 * Lead qualification levels in the sales pipeline.
 */
enum class LeadStatus(val label: String) {
    NEW("New Lead"),
    CONTACTED("Contacted"),
    QUALIFIED("Qualified"),
    PROPOSAL("Proposal Sent"),
    WON("Closed Won"),
    LOST("Closed Lost")
}

/**
 * Lead pipeline temperature.
 */
enum class LeadType(val label: String) {
    HOT("Hot Lead"),
    WARM("Warm Lead"),
    COLD("Cold Lead")
}

/**
 * Task completion status inside CRM.
 */
enum class TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}

/**
 * CRM User role authorization levels.
 */
enum class UserRole {
    ADMIN,
    MANAGER,
    STAFF
}

/**
 * CRM Lead data model synchronized with Firestore.
 */
data class CrmLead(
    val id: String = "",
    val name: String = "",
    val company: String = "",
    val email: String = "",
    val phone: String = "",
    val status: LeadStatus = LeadStatus.NEW,
    val type: LeadType = LeadType.WARM,
    val value: Double = 0.0,
    val industry: String = "",
    val assignedTo: String = "",
    val notes: String = "",
    
    // AI Assisted Business Automation metrics
    val aiScore: Int = 0, // Range 0-100 (Qualification)
    val aiSummary: String = "No summary generated yet.",
    val nextActionRecommendation: String = "Awaiting qualification context.",
    val isHighPriority: Boolean = false,
    
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
)

/**
 * Associated Task to drive conversion.
 */
data class CrmTask(
    val id: String = "",
    val leadId: String = "",
    val title: String = "",
    val description: String = "",
    val status: TaskStatus = TaskStatus.PENDING,
    val priority: String = "Medium", // Low, Medium, High
    val dueDate: Date = Date(),
    val createdAt: Date = Date()
)

/**
 * Scheduled event/meeting inside CRM Calendar.
 */
data class CrmMeeting(
    val id: String = "",
    val leadId: String = "",
    val title: String = "",
    val description: String = "",
    val dateTime: Date = Date(),
    val locationLink: String = "",
    val status: String = "Scheduled", // Scheduled, Completed, Cancelled
    val createdAt: Date = Date()
)

/**
 * Activity log timeline note for CRM customer card.
 */
data class CrmNote(
    val id: String = "",
    val leadId: String = "",
    val content: String = "",
    val creatorId: String = "",
    val type: String = "Note", // Note, Email, WhatsApp, Log
    val timestamp: Date = Date()
)
