package com.aura.ai.voice.repository

import com.aura.ai.voice.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Result of a single verbal turn during the active call.
 */
sealed class VoiceExchangeResult {
    data class UserTranscription(val text: String) : VoiceExchangeResult()
    data class AgentResponseChunk(val textChunk: String, val audioChunk: ByteArray?) : VoiceExchangeResult()
    data class FinalResponse(val fullText: String, val audioData: ByteArray?) : VoiceExchangeResult()
    data class Error(val throwable: Throwable) : VoiceExchangeResult()
}

/**
 * Repository interface for managing AI Voice Agent interactions and histories.
 */
interface VoiceAgentRepository {

    /**
     * Creates a new voice session reference inside Cloud Firestore.
     */
    suspend fun startVoiceSession(userId: String, settings: VoiceSettings): VoiceSession

    /**
     * Saves the final voice session document along with full transcripts in Firestore.
     */
    suspend fun saveVoiceSession(session: VoiceSession, messages: List<VoiceMessage>)

    /**
     * Retrieves a flow of historical voice sessions for a specific user from Firestore.
     */
    fun getVoiceSessions(userId: String): Flow<List<VoiceSession>>

    /**
     * Processes an verbal interaction by mapping speech inputs to intelligent text responses
     * and synthesizing natural voice streams. Handles interruption (barge-in) and streaming.
     */
    suspend fun processVoiceExchange(
        userId: String,
        sessionId: String,
        userSpeechInput: String,
        settings: VoiceSettings,
        conversationHistory: List<VoiceMessage>
    ): Flow<VoiceExchangeResult>

    /**
     * Generates a structural, high-converting outbound script template using Gemini models.
     */
    suspend fun generateCallScript(
        prompt: String,
        mode: AssistantMode,
        language: String
    ): CallScript
}
